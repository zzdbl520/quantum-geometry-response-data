#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
export MPLCONFIGDIR="$ROOT/.matplotlib"
mkdir -p "$MPLCONFIGDIR"

python scripts/verify_all_results.py
python scripts/verify_Cu2O2_results.py
python scripts/regenerate_all_system_figures.py
python scripts/plot_OsO4_main_mechanism_figure.py
python scripts/plot_OsO4_SI_factor_competition.py

echo "REPRODUCTION PASS: generated/ contains the audit summary and regenerated figures."
