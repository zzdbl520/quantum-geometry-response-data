#!/usr/bin/env python3
from pathlib import Path
import csv

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import FormatStrFormatter


HERE = Path(__file__).resolve().parent
CSV = (HERE.parent / "data" / "OsO4_def2TZVP" /
       "OsO4_CAS24_def2TZVP_CI_recovery" /
       "OsO4_def2TZVP_qgeom_summary.csv")

with CSV.open() as handle:
    rows = list(csv.DictReader(handle))

lam = np.array([float(row["lambda"]) for row in rows])
alpha = np.array([float(row["alpha_iso_au"]) for row in rows])
gff = np.array([float(row["g_ff_au"]) for row in rows])
delta = np.array([float(row["delta_geom_hartree"]) for row in rows])


def qvertex(xx, yy, ids):
    coeff = np.polyfit(xx[ids], yy[ids], 2)
    xv = -coeff[1] / (2 * coeff[0])
    return xv, np.polyval(coeff, xv), coeff


amin_x, amin_y, alpha_fit = qvertex(lam, alpha, [1, 2, 3])

# Exact interval decomposition of logarithmic slopes.
xmid = 0.5 * (lam[:-1] + lam[1:])
dlogg = np.diff(np.log(gff)) / np.diff(lam)
dlogd = np.diff(np.log(delta)) / np.diff(lam)
dloga = dlogg + dlogd
i = np.where(dloga[:-1] * dloga[1:] <= 0)[0][0]
xzero = xmid[i] - dloga[i] * (xmid[i + 1] - xmid[i]) / (dloga[i + 1] - dloga[i])
t = (xzero - xmid[i]) / (xmid[i + 1] - xmid[i])
gzero = dlogg[i] + t * (dlogg[i + 1] - dlogg[i])
dzero = dlogd[i] + t * (dlogd[i + 1] - dlogd[i])

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 9.2,
    "axes.linewidth": 0.9,
    "xtick.color": "black", "ytick.color": "black",
    "xtick.labelcolor": "black", "ytick.labelcolor": "black",
    "pdf.fonttype": 42, "ps.fonttype": 42,
    "svg.hashsalt": "qgeom-si",
})

blue = "#276FBF"
red = "#C23B3B"
black = "#202020"

fig, (axa, axb) = plt.subplots(1, 2, figsize=(7.10, 2.88),
                               gridspec_kw={"wspace": 0.27})


def style_axis(ax):
    ax.minorticks_off()
    ax.tick_params(which="major", direction="in", length=4.2, width=0.85,
                   top=True, right=True, colors="black")
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_color("black")
        spine.set_linewidth(0.9)
    ax.xaxis.set_major_formatter(FormatStrFormatter("%.2f"))


# (a) Response extremum.
style_axis(axa)
axa.plot(lam, alpha, color=blue, lw=1.7, marker="o", ms=4.0,
         mfc="white", mec=blue, mew=1.0, zorder=3)
xf = np.linspace(0.675, 0.725, 120)
axa.plot(xf, np.polyval(alpha_fit, xf), color=blue, lw=0.9, alpha=0.55)
axa.scatter([amin_x], [amin_y], marker="v", s=46, color=black, zorder=5)
axa.axvline(amin_x, color="0.55", ls=(0, (2.3, 2.3)), lw=0.8)
axa.annotate(r"$\lambda_{\min}^{\bar{\alpha}}=0.705$",
             xy=(amin_x, amin_y), xytext=(18, 17), textcoords="offset points",
             ha="left", va="bottom",
             arrowprops=dict(arrowstyle="-", lw=0.7, color=black))
axa.set_xlim(0.635, 1.015)
axa.set_ylim(25.2, 49.2)
axa.set_xticks([0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95, 1.00])
axa.set_yticks([26, 30, 34, 38, 42, 46])
axa.set_xlabel(r"Compression coordinate, $\lambda$")
axa.set_ylabel(r"$\bar{\alpha}$ (a.u.)")

# (b) Logarithmic-slope cancellation.
style_axis(axb)
axb.axhline(0, color="0.55", lw=0.8, ls=(0, (3, 2)), zorder=1)
axb.plot(xmid, dlogg, color=blue, lw=1.55, marker="o", ms=3.7,
         mfc="white", mec=blue, mew=0.95,
         label=r"$\partial_\lambda\ln\bar{g}_{FF}$", zorder=3)
axb.plot(xmid, dlogd, color=red, lw=1.55, marker="s", ms=3.5,
         mfc="white", mec=red, mew=0.95,
         label=r"$\partial_\lambda\ln\bar{\Delta}_{\rm geom}$", zorder=3)
axb.plot(xmid, dloga, color=black, lw=1.75, marker="D", ms=3.2,
         mfc="white", mec=black, mew=0.95,
         label=r"$\partial_\lambda\ln\bar{\alpha}$", zorder=4)
axb.axvline(xzero, color="0.50", lw=0.75, ls=(0, (2.3, 2.3)))
axb.scatter([xzero], [0], marker="v", s=43, color=black, zorder=6)
axb.scatter([xzero, xzero], [gzero, dzero], s=24,
            facecolors=[blue, red], edgecolors=[blue, red], zorder=6)
axb.annotate(r"cancellation at $\lambda=0.705$", xy=(xzero, 0),
             xytext=(0.745, -6.7), ha="left", va="center",
             arrowprops=dict(arrowstyle="-", lw=0.7, color=black))
axb.text(0.681, 3.55, r"$+2.35$", color=red, ha="right", va="bottom")
axb.text(0.681, -3.55, r"$-2.35$", color=blue, ha="right", va="top")
axb.set_xlim(0.645, 0.995)
axb.set_ylim(-16.5, 13.5)
axb.set_xticks([0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95])
axb.set_yticks([-15, -10, -5, 0, 5, 10])
axb.set_xlabel(r"Compression coordinate, $\lambda$")
axb.set_ylabel(r"Logarithmic slope, $\partial_\lambda\ln X$")
axb.legend(frameon=False, loc="upper right", fontsize=8.2,
           handlelength=1.55, labelspacing=0.35, borderaxespad=0.35)

# Labels outside axes.
fig.canvas.draw()
for label, ax in zip(["(a)", "(b)"], [axa, axb]):
    pos = ax.get_position()
    fig.text(pos.x0 - 0.033, pos.y1 + 0.018, label,
             fontsize=10.2, ha="left", va="bottom")

fig.subplots_adjust(left=0.092, right=0.982, bottom=0.205, top=0.865)
for ext in ("pdf", "svg", "png"):
    kwargs = {"dpi": 600} if ext == "png" else ({"metadata": {"CreationDate": None, "ModDate": None}} if ext == "pdf" else {})
    outdir = HERE.parent / "generated"
    outdir.mkdir(exist_ok=True)
    fig.savefig(outdir / f"OsO4_def2TZVP_main_mechanism_figure.{ext}",
                bbox_inches="tight", pad_inches=0.03, **kwargs)

print(f"alpha minimum = {amin_x:.9f}")
print(f"slope cancellation = {xzero:.9f}")
