#!/usr/bin/env python3
"""Finite-field CAS(24,17) polarizability scan for uniformly scaled OsO4.

Every +Fz and -Fz calculation starts from the converged zero-field CASSCF
checkpoint at the same geometry.  A z-directed field retains the C2v subgroup
of Td.  The field-complete extended-valence active space includes the occupied
T2 triplet that entered the smaller CAS(18,14) under an infinitesimal
C2v-compatible field.
"""

from __future__ import annotations

import argparse
import json
import os
import traceback
from collections import Counter
from pathlib import Path

import numpy as np
from pyscf import lib, mcscf, scf, symm
from pyscf.mcscf import chkfile as mc_chkfile
from pyscf.scf import chkfile as scf_chkfile


NCORE = 12
NCAS = 17
NELECAS = (12, 12)
ACTIVE_C2V_IRREPS = Counter({"A1": 6, "A2": 3, "B1": 4, "B2": 4})
DEFAULT_POINTS = {
    "smoke": [1.00],
    "compression": [1.00, 0.95, 0.90, 0.85, 0.80],
    "stretch": [1.00, 1.05, 1.10, 1.15, 1.20],
    "all": [1.00, 0.95, 0.90, 0.85, 0.80, 1.05, 1.10, 1.15, 1.20],
}


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=tuple(DEFAULT_POINTS), default="smoke")
    parser.add_argument("--points", nargs="+", type=float)
    parser.add_argument("--field", type=float, default=1.0e-3)
    parser.add_argument("--axis", choices=("x", "y", "z"), default="z")
    parser.add_argument("--reference-chk", default="lambda_1_CAS24fullvalence_D2_A.chk")
    parser.add_argument("--zero-root", default="OsO4_CAS24fullvalence_pilot")
    parser.add_argument("--output-root", default="OsO4_CAS24fullvalence_finite_field_C2v_F1em3")
    parser.add_argument("--memory-mb", type=int, default=60000)
    parser.add_argument("--fci-memory-mb", type=int, default=45000)
    parser.add_argument("--scf-max-cycle", type=int, default=200)
    parser.add_argument("--scf-newton-max-cycle", type=int, default=80)
    parser.add_argument("--macro-max-cycle", type=int, default=200)
    parser.add_argument("--micro-max-cycle", type=int, default=8)
    parser.add_argument("--max-stepsize", type=float, default=0.02)
    parser.add_argument("--scf-conv-tol", type=float, default=1.0e-12)
    parser.add_argument("--scf-conv-tol-grad", type=float, default=1.0e-8)
    parser.add_argument("--casscf-conv-tol", type=float, default=1.0e-9)
    parser.add_argument(
        "--require-converged-rhf",
        action="store_true",
        help=(
            "Abort when density-seeded DIIS and Newton RHF both fail. "
            "Otherwise the certified zero-field CASSCF orbitals are allowed "
            "to enter field-dependent CASSCF directly."
        ),
    )
    parser.add_argument("--min-field-sv", type=float, default=0.70)
    parser.add_argument(
        "--stability-only",
        action="store_true",
        help="Run only +F and its branch-continuity checks; do not form alpha.",
    )
    parser.add_argument(
        "--max-field-energy-shift",
        type=float,
        default=5.0e-3,
        help="Abort if |E(F)-E(0)| indicates relaxation to another branch.",
    )
    parser.add_argument("--overwrite", action="store_true")
    return parser.parse_args()


def lambda_tag(value: float) -> str:
    return f"lambda_{value:.3f}".replace(".", "p")


def write_json(path: Path, payload: dict) -> None:
    def convert(value):
        if isinstance(value, np.ndarray):
            return value.tolist()
        if isinstance(value, (np.floating, np.integer)):
            return value.item()
        raise TypeError(f"Cannot serialize {type(value)!r}")

    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2, sort_keys=True, default=convert) + "\n")
    tmp.replace(path)


def normalize_nelecas(value):
    result = tuple(int(x) for x in np.asarray(value).ravel())
    if len(result) != 2:
        raise RuntimeError(f"Invalid nelecas value: {value!r}")
    return result


def load_casscf_checkpoint(path: Path):
    mol, record = mc_chkfile.load_mcscf(str(path))
    if mol is None or record is None or "mo_coeff" not in record:
        raise RuntimeError(f"Cannot load CASSCF checkpoint {path}")
    ncore = int(np.asarray(record["ncore"]).ravel()[0])
    ncas = int(np.asarray(record["ncas"]).ravel()[0])
    nelecas = normalize_nelecas(record["nelecas"])
    if (ncore, ncas, nelecas) != (NCORE, NCAS, NELECAS):
        raise RuntimeError(
            f"{path} is not CAS(24,17): ncore={ncore}, ncas={ncas}, "
            f"nelecas={nelecas}"
        )
    energy = record.get("e_tot", record.get("e_mcscf"))
    if energy is None:
        raise RuntimeError(f"No total energy stored in {path}")
    return mol, record, np.asarray(record["mo_coeff"]), float(np.asarray(energy).ravel()[0])


def zero_checkpoint(args, lam: float) -> Path:
    if abs(lam - 1.0) < 1.0e-10:
        path = Path(args.reference_chk)
    else:
        direction = "compression" if lam < 1.0 else "stretch"
        path = Path(args.zero_root) / direction / lambda_tag(lam) / "casscf.chk"
    path = path.expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(f"Missing zero-field checkpoint for lambda={lam:.3f}: {path}")
    return path


def field_symmetry_copy(zero_mol, output: Path):
    mol = zero_mol.copy(deep=True)
    mol.symmetry = True
    mol.symmetry_subgroup = "C2v"
    mol.verbose = 4
    mol.output = str(output)
    mol.build(dump_input=False, parse_arg=False)
    if mol.groupname != "C2v":
        raise RuntimeError(
            f"Finite-field molecule has working group {mol.groupname}, expected C2v"
        )
    return mol


def orthonormalize_columns(block, overlap, label):
    if block.shape[1] == 0:
        return block
    metric = block.T.conj() @ overlap @ block
    metric = 0.5 * (metric + metric.T.conj())
    values, vectors = np.linalg.eigh(metric)
    if float(values.min()) < 1.0e-10:
        raise RuntimeError(
            f"{label} metric is linearly dependent; min eigenvalue={values.min():.3e}"
        )
    inverse_sqrt = (vectors * values**-0.5) @ vectors.T.conj()
    return block @ inverse_sqrt


def remove_space(block, space, overlap):
    if block.shape[1] == 0 or space.shape[1] == 0:
        return block
    return block - space @ (space.T.conj() @ overlap @ block)


def symmetrize_zero_mos(mol, zero_mo):
    overlap = mol.intor_symmetric("int1e_ovlp")
    blocks = (
        zero_mo[:, :NCORE],
        zero_mo[:, NCORE : NCORE + NCAS],
        zero_mo[:, NCORE + NCAS :],
    )
    mo_symm = np.hstack(
        [symm.symmetrize_space(mol, block, s=overlap, check=True) for block in blocks]
    )
    initial_irrep_ids = np.asarray(
        symm.label_orb_symm(
            mol, mol.irrep_id, mol.symm_orb, mo_symm, s=overlap, check=True
        ),
        dtype=int,
    )

    # Clean up the small numerical loss of orthogonality introduced by changing
    # from the D2 to the C2v symmetry basis.  The cleanup is performed inside
    # each C2v irrep and preserves the active subspace before treating core and
    # virtual orbitals, so no active--inactive contamination is introduced.
    mo0 = np.zeros_like(mo_symm)
    all_indices = np.arange(mo_symm.shape[1])
    for irrep_id in mol.irrep_id:
        same_irrep = initial_irrep_ids == int(irrep_id)
        core_idx = all_indices[same_irrep & (all_indices < NCORE)]
        active_idx = all_indices[
            same_irrep & (all_indices >= NCORE) & (all_indices < NCORE + NCAS)
        ]
        virtual_idx = all_indices[same_irrep & (all_indices >= NCORE + NCAS)]

        active = orthonormalize_columns(
            mo_symm[:, active_idx], overlap, f"active irrep {irrep_id}"
        )
        core = orthonormalize_columns(
            remove_space(mo_symm[:, core_idx], active, overlap),
            overlap,
            f"core irrep {irrep_id}",
        )
        occupied = np.hstack((core, active))
        virtual = orthonormalize_columns(
            remove_space(mo_symm[:, virtual_idx], occupied, overlap),
            overlap,
            f"virtual irrep {irrep_id}",
        )
        mo0[:, core_idx] = core
        mo0[:, active_idx] = active
        mo0[:, virtual_idx] = virtual

    # The independently generated C2v symmetry-orbital blocks can retain a
    # tiny (about 1e-8 here) cross-irrep overlap.  An irrep-local cleanup cannot
    # remove that residual.  Finish with a global, partition-preserving cleanup:
    # protect the complete 17-dimensional active span first, project it out of
    # the core, and finally project both occupied partitions out of the virtual
    # space.  The resulting cross-irrep mixing is only at numerical-noise level;
    # the active-space dimension and its physical span are unchanged.
    active_all = orthonormalize_columns(
        mo0[:, NCORE : NCORE + NCAS], overlap, "final active space"
    )
    core_all = orthonormalize_columns(
        remove_space(mo0[:, :NCORE], active_all, overlap),
        overlap,
        "final core space",
    )
    occupied_all = np.hstack((core_all, active_all))
    virtual_all = orthonormalize_columns(
        remove_space(mo0[:, NCORE + NCAS :], occupied_all, overlap),
        overlap,
        "final virtual space",
    )
    mo0 = np.hstack((core_all, active_all, virtual_all))

    orth_error = float(
        np.max(np.abs(mo0.T.conj() @ overlap @ mo0 - np.eye(mo0.shape[1])))
    )
    if orth_error > 1.0e-10:
        raise RuntimeError(f"C2v-cleaned MO orthonormality error {orth_error:.3e}")

    irrep_ids = np.asarray(
        symm.label_orb_symm(
            mol, mol.irrep_id, mol.symm_orb, mo0, s=overlap, check=True
        ),
        dtype=int,
    )
    id_to_name = {int(i): str(n) for i, n in zip(mol.irrep_id, mol.irrep_name)}
    names = [id_to_name[int(i)] for i in irrep_ids]
    active_counts = Counter(names[NCORE : NCORE + NCAS])
    if active_counts != ACTIVE_C2V_IRREPS:
        raise RuntimeError(
            f"C2v active irrep content {dict(active_counts)}; "
            f"expected {dict(ACTIVE_C2V_IRREPS)}"
        )
    return lib.tag_array(mo0, orbsym=irrep_ids), orth_error, active_counts


def field_hamiltonian(mol, field_vector):
    hcore0 = scf.hf.get_hcore(mol)
    with mol.with_common_orig((0.0, 0.0, 0.0)):
        r_ao = mol.intor_symmetric("int1e_r", comp=3)
    hcore = hcore0 + np.einsum("x,xij->ij", field_vector, r_ao)

    # For ECP atoms, PySCF's atom_charge already returns the effective ionic
    # charge Z-N_core.  Subtracting atom_nelec_core again would be incorrect.
    ionic_charges = np.asarray(mol.atom_charges(), dtype=float)
    nuclear_dipole = np.einsum("i,ix->x", ionic_charges, mol.atom_coords(unit="Bohr"))
    nuclear_field_energy = -float(np.dot(field_vector, nuclear_dipole))
    return hcore, float(mol.energy_nuc() + nuclear_field_energy), nuclear_dipole


def hcore_offblock_error(mol, hcore):
    error = 0.0
    for i, left in enumerate(mol.symm_orb):
        for right in mol.symm_orb[i + 1 :]:
            block = left.T @ hcore @ right
            if block.size:
                error = max(error, float(np.max(np.abs(block))))
    return error


def active_irrep_counts(mol, mo):
    overlap = mol.intor_symmetric("int1e_ovlp")
    ids = np.asarray(
        symm.label_orb_symm(
            mol, mol.irrep_id, mol.symm_orb, mo, s=overlap, check=True
        ),
        dtype=int,
    )
    id_to_name = {int(i): str(n) for i, n in zip(mol.irrep_id, mol.irrep_name)}
    names = [id_to_name[int(i)] for i in ids]
    counts = Counter(names[NCORE : NCORE + NCAS])
    if counts != ACTIVE_C2V_IRREPS:
        raise RuntimeError(
            f"Optimized C2v active irrep content {dict(counts)}; "
            f"expected {dict(ACTIVE_C2V_IRREPS)}"
        )
    return counts


def active_metrics(mol, zero_mo, field_mo):
    overlap = mol.intor_symmetric("int1e_ovlp")
    left = zero_mo[:, NCORE : NCORE + NCAS]
    right = field_mo[:, NCORE : NCORE + NCAS]
    singular_values = np.linalg.svd(left.T @ overlap @ right, compute_uv=False)
    singular_values = np.clip(np.real(singular_values), 0.0, 1.0)
    angles = np.degrees(np.arccos(singular_values))
    return {
        "singular_values": singular_values.tolist(),
        "min_singular_value": float(singular_values.min()),
        "max_principal_angle_deg": float(angles.max()),
    }


def natural_occupations(mc):
    dm1 = mc.fcisolver.make_rdm1(mc.ci, mc.ncas, mc.nelecas)
    return np.linalg.eigvalsh(0.5 * (dm1 + dm1.T.conj()))[::-1]


def zero_rhf_density(zero_path: Path, mol):
    """Return the same-geometry zero-field RHF density when available."""
    rhf_path = zero_path.parent / "rhf.chk"
    if not rhf_path.is_file():
        return None, None
    _, record = scf_chkfile.load_scf(str(rhf_path))
    if record is None or "mo_coeff" not in record or "mo_occ" not in record:
        return None, None
    coeff = np.asarray(record["mo_coeff"])
    occ = np.asarray(record["mo_occ"])
    if coeff.shape != (mol.nao_nr(), mol.nao_nr()) or occ.shape != (mol.nao_nr(),):
        return None, None
    dm = np.einsum("pi,i,qi->pq", coeff, occ, coeff.conj(), optimize=True)
    return np.asarray(dm), rhf_path


def configure_field_rhf(args, mol, run_dir, hcore, energy_nuc):
    mf = scf.RHF(mol)
    mf.max_memory = args.memory_mb
    mf.max_cycle = args.scf_max_cycle
    mf.conv_tol = args.scf_conv_tol
    mf.conv_tol_grad = args.scf_conv_tol_grad
    mf.chkfile = str(run_dir / "rhf.chk")
    mf.get_hcore = lambda *unused: hcore
    mf.energy_nuc = lambda *unused: energy_nuc
    return mf


def run_auxiliary_rhf(args, mol, run_dir, hcore, energy_nuc, zero_path):
    """Use the zero-RHF density, then Newton, without changing CASSCF gates."""
    dm0, dm_source = zero_rhf_density(zero_path, mol)
    mf = configure_field_rhf(args, mol, run_dir, hcore, energy_nuc)
    if dm0 is None:
        mf.kernel()
        strategy = "default-diis"
    else:
        mf.kernel(dm0=dm0)
        strategy = "zero-rhf-density-diis"
    if mf.converged:
        return mf, strategy, dm_source

    newton = mf.newton()
    newton.max_cycle = args.scf_newton_max_cycle
    newton.conv_tol = args.scf_conv_tol
    newton.conv_tol_grad = args.scf_conv_tol_grad
    newton.kernel(dm0=dm0)
    if newton.converged:
        return newton, strategy + "+newton", dm_source
    if args.require_converged_rhf:
        raise RuntimeError(
            "finite-field RHF failed after density-seeded DIIS and Newton"
        )
    return newton, strategy + "+newton+direct-casscf", dm_source


def run_field(args, lam, sign, zero_path, zero_mol, zero_mo, zero_energy, point_root):
    label = "plus" if sign > 0 else "minus"
    run_dir = point_root / label
    run_dir.mkdir(parents=True, exist_ok=True)
    summary_path = run_dir / "summary.json"
    chk_path = run_dir / "casscf.chk"
    if summary_path.exists() and chk_path.exists() and not args.overwrite:
        summary = json.loads(summary_path.read_text())
        if summary.get("converged") is True:
            expected_field = float(sign * args.field)
            stored_field = float(summary.get("field_au", np.nan))
            stored_axis = summary.get("axis")
            if not np.isclose(stored_field, expected_field, rtol=0.0, atol=1.0e-15):
                raise RuntimeError(
                    f"Existing {summary_path} used field {stored_field}; requested "
                    f"{expected_field}. Use a different OUTPUT_ROOT."
                )
            if stored_axis != args.axis:
                raise RuntimeError(
                    f"Existing {summary_path} used axis {stored_axis}; requested "
                    f"{args.axis}. Use a different OUTPUT_ROOT."
                )
            print(
                f"FIELD_RESUME lambda={lam:.3f} sign={label} "
                f"E={summary['energy_hartree']:.12f}",
                flush=True,
            )
            return summary

    log_path = run_dir / "pyscf.out"
    mol = field_symmetry_copy(zero_mol, log_path)
    overlap = mol.intor_symmetric("int1e_ovlp")
    orth_error = float(np.max(np.abs(zero_mo.T @ overlap @ zero_mo - np.eye(zero_mo.shape[1]))))
    if orth_error > 1.0e-8:
        raise RuntimeError(f"lambda={lam:.3f}: zero-field MO orthonormality error {orth_error:.3e}")
    mo0, symm_orth_error, initial_active_counts = symmetrize_zero_mos(mol, zero_mo)

    axis_index = {"x": 0, "y": 1, "z": 2}[args.axis]
    vector = np.zeros(3)
    vector[axis_index] = sign * args.field
    hcore, energy_nuc, nuclear_dipole = field_hamiltonian(mol, vector)
    hcore_error = hcore_offblock_error(mol, hcore)
    if hcore_error > 1.0e-9:
        raise RuntimeError(
            f"lambda={lam:.3f} sign={label}: field Hamiltonian is not C2v "
            f"block diagonal; max off-block element={hcore_error:.3e}"
        )

    mf, rhf_strategy, rhf_dm_source = run_auxiliary_rhf(
        args, mol, run_dir, hcore, energy_nuc, zero_path
    )

    mc = mcscf.CASSCF(mf, NCAS, NELECAS, ncore=NCORE)
    mc.max_memory = args.memory_mb
    mc.fcisolver.max_memory = args.fci_memory_mb
    mc.fcisolver.pspace_size = 1200
    mc.fcisolver.max_cycle = 400
    mc.fcisolver.wfnsym = "A1"
    mc.natorb = True
    mc.canonicalization = True
    mc.max_cycle_macro = args.macro_max_cycle
    mc.max_cycle_micro = args.micro_max_cycle
    mc.max_stepsize = args.max_stepsize
    mc.conv_tol = args.casscf_conv_tol
    mc.chkfile = str(chk_path)
    mc.kernel(mo0)
    if not mc.converged:
        raise RuntimeError(f"lambda={lam:.3f} sign={label}: finite-field CASSCF failed")

    field_energy_shift = float(mc.e_tot - zero_energy)
    if abs(field_energy_shift) > args.max_field_energy_shift:
        raise RuntimeError(
            f"lambda={lam:.3f} sign={label}: |E(F)-E(0)|="
            f"{abs(field_energy_shift):.6e} Eh exceeds "
            f"{args.max_field_energy_shift:.6e} Eh; probable branch change"
        )

    final_counts = active_irrep_counts(mol, np.asarray(mc.mo_coeff))
    metrics = active_metrics(mol, zero_mo, np.asarray(mc.mo_coeff))
    if metrics["min_singular_value"] < args.min_field_sv:
        raise RuntimeError(
            f"lambda={lam:.3f} sign={label}: field active-space continuity failed; "
            f"min_sv={metrics['min_singular_value']:.8f} < {args.min_field_sv:.8f}"
        )

    occ = natural_occupations(mc)
    s2, multiplicity = mc.fcisolver.spin_square(mc.ci, NCAS, NELECAS)
    dm1 = mc.make_rdm1()
    dipole = scf.hf.dip_moment(mol, dm1, unit="AU", verbose=0)
    summary = {
        "lambda": lam,
        "sign": label,
        "axis": args.axis,
        "field_working_group": mol.groupname,
        "field_au": float(sign * args.field),
        "field_vector_au": vector.tolist(),
        "converged": True,
        "zero_checkpoint": str(zero_path),
        "checkpoint": str(chk_path.resolve()),
        "energy_hartree": float(mc.e_tot),
        "field_minus_zero_energy_hartree": field_energy_shift,
        "rhf_energy_hartree": float(mf.e_tot),
        "rhf_converged": bool(mf.converged),
        "rhf_initialization_strategy": rhf_strategy,
        "zero_rhf_density_checkpoint": (
            str(rhf_dm_source.resolve()) if rhf_dm_source is not None else None
        ),
        "ncore": NCORE,
        "ncas": NCAS,
        "nelecas": list(NELECAS),
        "natural_occupations": occ.tolist(),
        "initial_active_irrep_counts": dict(initial_active_counts),
        "optimized_active_irrep_counts": dict(final_counts),
        "zero_to_field_active_space": metrics,
        "spin_square": float(s2),
        "spin_multiplicity": float(multiplicity),
        "dipole_au": np.asarray(dipole).tolist(),
        "effective_ionic_nuclear_dipole_au": nuclear_dipole.tolist(),
        "zero_mo_orthonormality_max_error": orth_error,
        "c2v_symmetrized_mo_orthonormality_max_error": symm_orth_error,
        "field_hcore_max_off_irrep_block_element": hcore_error,
        "omp_num_threads": os.environ.get("OMP_NUM_THREADS"),
    }
    write_json(summary_path, summary)
    print(
        f"FIELD_DONE lambda={lam:.3f} sign={label} E={mc.e_tot:.12f} "
        f"min_sv={metrics['min_singular_value']:.8f} "
        f"angle={metrics['max_principal_angle_deg']:.4f}deg",
        flush=True,
    )
    return summary


def pair_summary(args, lam, zero_path, zero_energy, plus, minus, point_root):
    eplus = float(plus["energy_hartree"])
    eminus = float(minus["energy_hartree"])
    field = float(args.field)
    alpha = -(eplus + eminus - 2.0 * zero_energy) / field**2
    odd_energy = 0.5 * (eplus - eminus)
    inferred_dipole = -odd_energy / field
    occ_plus = np.asarray(plus["natural_occupations"])
    occ_minus = np.asarray(minus["natural_occupations"])
    result = {
        "lambda": lam,
        "axis": args.axis,
        "field_magnitude_au": field,
        "zero_checkpoint": str(zero_path),
        "zero_energy_hartree": zero_energy,
        "plus_energy_hartree": eplus,
        "minus_energy_hartree": eminus,
        "alpha_axis_au": float(alpha),
        "alpha_iso_au": float(alpha),
        "td_isotropy_used": True,
        "field_working_group": "C2v",
        "plus_minus_energy_difference_hartree": eplus - eminus,
        "odd_energy_half_difference_hartree": odd_energy,
        "inferred_zero_field_dipole_au": inferred_dipole,
        "plus_minus_max_natural_occupation_difference": float(
            np.max(np.abs(occ_plus - occ_minus))
        ),
        "plus_min_active_sv": plus["zero_to_field_active_space"]["min_singular_value"],
        "minus_min_active_sv": minus["zero_to_field_active_space"]["min_singular_value"],
    }
    write_json(point_root / "polarizability.json", result)
    print(
        f"POLAR_DONE lambda={lam:.3f} alpha_iso={alpha:.10f} "
        f"dE_pm={eplus-eminus:.3e}Eh "
        f"min_sv={min(result['plus_min_active_sv'], result['minus_min_active_sv']):.8f}",
        flush=True,
    )


def main():
    args = parse_args()
    if args.field <= 0.0:
        raise ValueError("--field must be positive")
    if args.axis != "z":
        raise ValueError("This C2v implementation currently supports only a z-directed field")
    points = args.points if args.points else DEFAULT_POINTS[args.mode]
    if len({round(x, 10) for x in points}) != len(points):
        raise ValueError(f"Duplicate lambda points: {points}")

    output_root = Path(args.output_root).expanduser().resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    config_path = output_root / "run_config.json"
    if config_path.exists() and not args.overwrite:
        old_config = json.loads(config_path.read_text())
        old_field = float(old_config.get("field_magnitude_au", np.nan))
        old_axis = old_config.get("axis")
        if not np.isclose(old_field, args.field, rtol=0.0, atol=1.0e-15):
            raise RuntimeError(
                f"Output root {output_root} already contains field {old_field}; "
                f"requested {args.field}. Use a different --output-root."
            )
        if old_axis != args.axis:
            raise RuntimeError(
                f"Output root {output_root} already contains axis {old_axis}; "
                f"requested {args.axis}. Use a different --output-root."
            )
    write_json(
        config_path,
        {
            "mode": args.mode,
            "points": points,
            "field_magnitude_au": args.field,
            "axis": args.axis,
            "reference_checkpoint": str(Path(args.reference_chk).expanduser().resolve()),
            "zero_root": str(Path(args.zero_root).expanduser().resolve()),
            "ncore": NCORE,
            "ncas": NCAS,
            "nelecas": list(NELECAS),
            "memory_mb": args.memory_mb,
            "fci_memory_mb": args.fci_memory_mb,
            "scf_max_cycle": args.scf_max_cycle,
            "scf_newton_max_cycle": args.scf_newton_max_cycle,
            "require_converged_rhf": bool(args.require_converged_rhf),
            "min_field_sv": args.min_field_sv,
            "max_field_energy_shift_hartree": args.max_field_energy_shift,
        },
    )

    for lam in points:
        point_root = output_root / lambda_tag(lam)
        point_root.mkdir(parents=True, exist_ok=True)
        try:
            zero_path = zero_checkpoint(args, lam)
            zero_mol, _, zero_mo, zero_energy = load_casscf_checkpoint(zero_path)
            plus = run_field(
                args, lam, +1, zero_path, zero_mol, zero_mo, zero_energy, point_root
            )
            if args.stability_only:
                print(
                    f"FIELD_STABILITY_DONE lambda={lam:.3f} "
                    f"dE={plus['field_minus_zero_energy_hartree']:.6e}Eh "
                    f"min_sv={plus['zero_to_field_active_space']['min_singular_value']:.8f}",
                    flush=True,
                )
                continue
            minus = run_field(
                args, lam, -1, zero_path, zero_mol, zero_mo, zero_energy, point_root
            )
            pair_summary(args, lam, zero_path, zero_energy, plus, minus, point_root)
        except Exception as exc:
            write_json(
                point_root / "failure.json",
                {
                    "lambda": lam,
                    "error": str(exc),
                    "traceback": traceback.format_exc(),
                },
            )
            print(f"FIELD_POINT_FAILED lambda={lam:.3f}: {exc}", flush=True)
            raise
    status = "FIELD_STABILITY_SCAN_DONE" if args.stability_only else "FINITE_FIELD_DONE"
    print(f"{status} mode={args.mode} points={points}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
