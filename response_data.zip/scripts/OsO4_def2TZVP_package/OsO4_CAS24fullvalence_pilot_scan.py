#!/usr/bin/env python3
"""Bidirectional CAS(24,17) A1+pi pilot scan for uniform OsO4 scaling.

The converged lambda=1 CASSCF checkpoint is the only root.  At every new
geometry the complete previous MO basis is transported with the cross-AO
overlap, while the 17-dimensional active subspace is kept intact.  This is
deliberately different from reselecting orbitals by RHF energy indices.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import traceback
from collections import Counter
from pathlib import Path

import numpy as np
from pyscf import gto, lib, mcscf, scf, symm
from pyscf.mcscf import chkfile as mc_chkfile


NCORE_EXPECTED = 12
NCAS_EXPECTED = 17
NELECAS_EXPECTED = (12, 12)
ACTIVE_IRREPS_EXPECTED = Counter({"A": 5, "B1": 4, "B2": 4, "B3": 4})
DEFAULT_POINTS = {
    "compression": [0.95, 0.90, 0.85, 0.80],
    "stretch": [1.05, 1.10, 1.15, 1.20],
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--direction", choices=("compression", "stretch"), required=True)
    parser.add_argument("--reference-chk", default="lambda_1_CAS24fullvalence_D2_A.chk")
    parser.add_argument("--output-root", default="OsO4_CAS24fullvalence_pilot")
    parser.add_argument(
        "--points",
        nargs="+",
        type=float,
        help="Override lambda values; order must continue away from lambda=1.",
    )
    parser.add_argument("--memory-mb", type=int, default=60000)
    parser.add_argument("--fci-memory-mb", type=int, default=45000)
    parser.add_argument("--scf-max-cycle", type=int, default=200)
    parser.add_argument("--macro-max-cycle", type=int, default=200)
    parser.add_argument("--micro-max-cycle", type=int, default=8)
    parser.add_argument("--max-stepsize", type=float, default=0.02)
    parser.add_argument("--scf-conv-tol", type=float, default=1.0e-12)
    parser.add_argument("--scf-conv-tol-grad", type=float, default=1.0e-8)
    parser.add_argument("--casscf-conv-tol", type=float, default=1.0e-8)
    parser.add_argument(
        "--min-transport-eigenvalue",
        type=float,
        default=1.0e-10,
        help="Abort if whole-MO projection becomes linearly dependent.",
    )
    parser.add_argument(
        "--min-consecutive-sv",
        type=float,
        default=0.70,
        help="Abort if the optimized active space loses continuity with the prior point.",
    )
    parser.add_argument("--overwrite", action="store_true", help="Recompute existing converged points.")
    return parser.parse_args()


def lambda_tag(value: float) -> str:
    return f"lambda_{value:.3f}".replace(".", "p")


def json_ready(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    if isinstance(value, complex):
        return {"real": value.real, "imag": value.imag}
    raise TypeError(f"Cannot serialize {type(value)!r}")


def write_json(path: Path, payload: dict) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2, sort_keys=True, default=json_ready) + "\n")
    tmp.replace(path)


def normalize_nelecas(value) -> tuple[int, int]:
    vals = tuple(int(x) for x in np.asarray(value).ravel())
    if len(vals) != 2:
        raise RuntimeError(f"Expected alpha/beta active electrons, got {value!r}")
    return vals


def label_orbitals(mol, mo, overlap) -> tuple[np.ndarray, list[str]]:
    ids = np.asarray(
        symm.label_orb_symm(
            mol, mol.irrep_id, mol.symm_orb, mo, s=overlap, check=True
        ),
        dtype=int,
    )
    id_to_name = {int(i): str(n) for i, n in zip(mol.irrep_id, mol.irrep_name)}
    names = [id_to_name[int(i)] for i in ids]
    return ids, names


def assert_active_irreps(names: list[str], ncore: int, ncas: int, where: str) -> Counter:
    counts = Counter(names[ncore : ncore + ncas])
    if counts != ACTIVE_IRREPS_EXPECTED:
        raise RuntimeError(
            f"{where}: active irrep content {dict(counts)}; "
            f"expected {dict(ACTIVE_IRREPS_EXPECTED)}"
        )
    return counts


def load_mc_state(chk_path: Path):
    mol, record = mc_chkfile.load_mcscf(str(chk_path))
    if mol is None or record is None:
        raise RuntimeError(f"Could not load an MCSCF state from {chk_path}")
    required = ("mo_coeff", "ncore", "ncas", "nelecas")
    missing = [key for key in required if key not in record]
    if missing:
        raise RuntimeError(f"Checkpoint {chk_path} is missing keys: {missing}")
    mo = np.asarray(record["mo_coeff"])
    ncore = int(np.asarray(record["ncore"]).ravel()[0])
    ncas = int(np.asarray(record["ncas"]).ravel()[0])
    nelecas = normalize_nelecas(record["nelecas"])
    if (ncore, ncas, nelecas) != (NCORE_EXPECTED, NCAS_EXPECTED, NELECAS_EXPECTED):
        raise RuntimeError(
            "Checkpoint is not the validated CAS(24,17) singlet: "
            f"ncore={ncore}, ncas={ncas}, nelecas={nelecas}"
        )
    if mo.ndim != 2 or mo.shape[0] != mol.nao_nr() or mo.shape[1] != mol.nao_nr():
        raise RuntimeError(f"Unexpected MO shape {mo.shape} for nao={mol.nao_nr()}")
    return mol, record, mo, ncore, ncas, nelecas


def validate_points(direction: str, points: list[float]) -> None:
    if not points:
        raise ValueError("At least one lambda point is required")
    if direction == "compression":
        ok = all(0.0 < x < 1.0 for x in points) and all(
            points[i] > points[i + 1] for i in range(len(points) - 1)
        )
    else:
        ok = all(x > 1.0 for x in points) and all(
            points[i] < points[i + 1] for i in range(len(points) - 1)
        )
    if not ok:
        raise ValueError(
            f"{direction} points must be strictly ordered away from 1.0; got {points}"
        )


def scaled_molecule(reference_mol, lam: float, output_file: Path):
    coords = reference_mol.atom_coords(unit="Bohr")
    charges = reference_mol.atom_charges()
    heavy = int(np.argmax(charges))
    center = coords[heavy]
    new_coords = center + lam * (coords - center)

    mol = reference_mol.copy(deep=True)
    mol.atom = [
        (reference_mol.atom_symbol(i), tuple(float(x) for x in new_coords[i]))
        for i in range(reference_mol.natm)
    ]
    mol.unit = "Bohr"
    mol.symmetry = True
    mol.symmetry_subgroup = "D2"
    mol.verbose = 4
    mol.output = str(output_file)
    mol.build(dump_input=False, parse_arg=False)

    if mol.groupname != "D2":
        raise RuntimeError(f"lambda={lam}: working symmetry is {mol.groupname}, not D2")
    distances = np.linalg.norm(new_coords - new_coords[heavy], axis=1)
    ligand_distances = np.delete(distances, heavy)
    if np.ptp(ligand_distances) > 1.0e-9:
        raise RuntimeError(f"lambda={lam}: four Os-O distances are not equal")
    return mol, float(np.mean(ligand_distances)), new_coords


def symmetric_inverse_sqrt(matrix: np.ndarray, min_eig: float, label: str):
    matrix = 0.5 * (matrix + matrix.T.conj())
    vals, vecs = np.linalg.eigh(matrix)
    if float(vals.min()) < min_eig:
        raise RuntimeError(
            f"{label} transport metric is ill-conditioned: "
            f"min eigenvalue={vals.min():.3e}"
        )
    inverse_sqrt = (vecs * (vals ** -0.5)) @ vecs.T.conj()
    return inverse_sqrt, vals


def orthonormalize_block(block, overlap, min_eig, label):
    metric = block.T.conj() @ overlap @ block
    invsqrt, eigs = symmetric_inverse_sqrt(metric, min_eig, label)
    return block @ invsqrt, eigs


def remove_space(block, space, overlap):
    if space.shape[1] == 0:
        return block
    return block - space @ (space.T.conj() @ overlap @ block)


def transport_mos(prev_mol, prev_mo, new_mol, ncore, ncas, min_eig):
    s_new = new_mol.intor_symmetric("int1e_ovlp")
    s_new_prev = gto.intor_cross("int1e_ovlp", new_mol, prev_mol)
    raw = np.linalg.solve(s_new, s_new_prev @ prev_mo)

    # Preserve the active space exactly: orthonormalize its projected columns
    # first.  Core and virtual orbitals are then made orthogonal to that fixed
    # 17-D span.  A global Lowdin step would mix active and inactive blocks and
    # defeat the physical continuation criterion.
    raw_core = raw[:, :ncore]
    raw_active = raw[:, ncore : ncore + ncas]
    raw_virtual = raw[:, ncore + ncas :]
    active, active_eigs = orthonormalize_block(
        raw_active, s_new, min_eig, "active-space"
    )
    core0 = remove_space(raw_core, active, s_new)
    core, core_eigs = orthonormalize_block(core0, s_new, min_eig, "core-space")
    occupied_space = np.hstack((core, active))
    virtual0 = remove_space(raw_virtual, occupied_space, s_new)
    virtual, virtual_eigs = orthonormalize_block(
        virtual0, s_new, min_eig, "virtual-space"
    )
    projected = np.hstack((core, active, virtual))

    # Symmetrize within core, active, and virtual spaces separately.  The
    # spaces themselves are unchanged, so the complete active subspace cannot
    # be contaminated by energy-order crossings.
    bounds = (0, ncore, ncore + ncas, projected.shape[1])
    blocks = []
    for start, stop in zip(bounds[:-1], bounds[1:]):
        block = projected[:, start:stop]
        blocks.append(symm.symmetrize_space(new_mol, block, s=s_new, check=True))
    mo0 = np.hstack(blocks)
    orth_error = float(np.max(np.abs(mo0.T.conj() @ s_new @ mo0 - np.eye(mo0.shape[1]))))
    if orth_error > 1.0e-8:
        raise RuntimeError(f"Transported MO orthonormality error is {orth_error:.3e}")

    irrep_ids, irrep_names = label_orbitals(new_mol, mo0, s_new)
    counts = assert_active_irreps(irrep_names, ncore, ncas, "transported guess")
    mo0 = lib.tag_array(mo0, orbsym=irrep_ids)
    diagnostics = {
        "active_transport_metric_min_eigenvalue": float(active_eigs.min()),
        "active_transport_metric_max_eigenvalue": float(active_eigs.max()),
        "core_after_active_projection_min_eigenvalue": float(core_eigs.min()),
        "virtual_after_occupied_projection_min_eigenvalue": float(virtual_eigs.min()),
        "transported_mo_orthonormality_max_error": orth_error,
        "transported_active_irrep_counts": dict(counts),
    }
    return mo0, diagnostics


def subspace_metrics(mol_left, mo_left, mol_right, mo_right, ncore, ncas):
    s_left_right = gto.intor_cross("int1e_ovlp", mol_left, mol_right)
    left = mo_left[:, ncore : ncore + ncas]
    right = mo_right[:, ncore : ncore + ncas]
    singular_values = np.linalg.svd(left.T.conj() @ s_left_right @ right, compute_uv=False)
    singular_values = np.clip(np.real(singular_values), 0.0, 1.0)
    angles = np.degrees(np.arccos(singular_values))
    projector_distance = float(np.sqrt(max(0.0, 2.0 * ncas - 2.0 * np.sum(singular_values**2))))
    return {
        "singular_values": singular_values.tolist(),
        "min_singular_value": float(singular_values.min()),
        "max_principal_angle_deg": float(angles.max()),
        "principal_angles_deg": angles.tolist(),
        "projector_distance": projector_distance,
    }


def active_natural_occupations(mc) -> np.ndarray:
    dm1 = mc.fcisolver.make_rdm1(mc.ci, mc.ncas, mc.nelecas)
    occ = np.linalg.eigvalsh(0.5 * (dm1 + dm1.T.conj()))[::-1]
    return np.real_if_close(occ)


def make_reference_summary(mol, record, mo, ncore, ncas):
    s = mol.intor_symmetric("int1e_ovlp")
    _, names = label_orbitals(mol, mo, s)
    counts = assert_active_irreps(names, ncore, ncas, "reference checkpoint")
    energy = record.get("e_tot", record.get("e_mcscf", None))
    if energy is not None:
        energy = float(np.asarray(energy).ravel()[0])
    return {
        "lambda": 1.0,
        "status": "reference",
        "converged": True,
        "energy_hartree": energy,
        "active_irrep_counts": dict(counts),
        "active_orbital_indices_one_based": list(range(ncore + 1, ncore + ncas + 1)),
    }


def run_point(args, lam, reference_mol, prev_mol, prev_mo, ncore, ncas, nelecas, point_dir):
    point_dir.mkdir(parents=True, exist_ok=True)
    summary_path = point_dir / "summary.json"
    checkpoint_path = point_dir / "casscf.chk"
    if summary_path.exists() and checkpoint_path.exists() and not args.overwrite:
        summary = json.loads(summary_path.read_text())
        if summary.get("converged") is True:
            mol, record, mo, nc, na, ne = load_mc_state(checkpoint_path)
            if (nc, na, ne) != (ncore, ncas, nelecas):
                raise RuntimeError(f"Incompatible resume checkpoint: {checkpoint_path}")
            print(f"RESUME lambda={lam:.3f} from {checkpoint_path}", flush=True)
            return mol, mo, summary

    log_path = point_dir / "pyscf.out"
    mol, os_o_bohr, coords_bohr = scaled_molecule(reference_mol, lam, log_path)
    mo0, transport = transport_mos(
        prev_mol, prev_mo, mol, ncore, ncas, args.min_transport_eigenvalue
    )
    guess_metrics = subspace_metrics(prev_mol, prev_mo, mol, mo0, ncore, ncas)

    mf = scf.RHF(mol)
    mf.max_cycle = args.scf_max_cycle
    mf.conv_tol = args.scf_conv_tol
    mf.conv_tol_grad = args.scf_conv_tol_grad
    mf.max_memory = args.memory_mb
    mf.chkfile = str(point_dir / "rhf.chk")
    # RHF is auxiliary here: the CASSCF branch is defined by transporting
    # the complete preceding converged CASSCF orbital space.  If a failed RHF
    # checkpoint exists, reuse its final density before allowing direct entry
    # into CASSCF with the transported orbitals.
    dm0 = None
    rhf_chk = Path(mf.chkfile)
    if rhf_chk.is_file():
        try:
            dm0 = scf.hf.init_guess_by_chkfile(
                mol, str(rhf_chk), project=False
            )
            print(
                f"RHF_RESTART lambda={lam:.3f} from {rhf_chk}",
                flush=True,
            )
        except Exception as exc:
            print(
                f"RHF_RESTART_WARNING lambda={lam:.3f}: {exc}",
                flush=True,
            )

    mf.kernel(dm0=dm0)
    if not mf.converged:
        print(
            f"AUX_RHF_BYPASS lambda={lam:.3f}: symmetry-adapted RHF "
            "did not converge; continuing CASSCF from the transported "
            "previous CASSCF orbitals",
            flush=True,
        )

    mc = mcscf.CASSCF(mf, ncas, nelecas, ncore=ncore)
    mc.max_memory = args.memory_mb
    mc.fcisolver.max_memory = args.fci_memory_mb
    mc.fcisolver.pspace_size = 1200
    mc.fcisolver.max_cycle = 400
    mc.fcisolver.wfnsym = "A"
    mc.natorb = True
    mc.canonicalization = True
    mc.max_cycle_macro = args.macro_max_cycle
    mc.max_cycle_micro = args.micro_max_cycle
    mc.max_stepsize = args.max_stepsize
    mc.conv_tol = args.casscf_conv_tol
    mc.chkfile = str(checkpoint_path)
    mc.kernel(mo0)
    if not mc.converged:
        raise RuntimeError(f"lambda={lam:.3f}: CASSCF did not converge")

    final_mo = np.asarray(mc.mo_coeff)
    s = mol.intor_symmetric("int1e_ovlp")
    _, final_names = label_orbitals(mol, final_mo, s)
    final_counts = assert_active_irreps(final_names, ncore, ncas, "optimized CASSCF")
    consecutive = subspace_metrics(prev_mol, prev_mo, mol, final_mo, ncore, ncas)
    initial_to_final = subspace_metrics(mol, mo0, mol, final_mo, ncore, ncas)
    if consecutive["min_singular_value"] < args.min_consecutive_sv:
        raise RuntimeError(
            f"lambda={lam:.3f}: active-space continuity failed; minimum singular "
            f"value={consecutive['min_singular_value']:.6f} < {args.min_consecutive_sv:.6f}"
        )

    occ = active_natural_occupations(mc)
    dm1 = mc.make_rdm1()
    _, charges = scf.hf.mulliken_pop(mol, dm1, s=s, verbose=0)
    dipole = scf.hf.dip_moment(mol, dm1, unit="Debye", verbose=0)
    s2, multiplicity = mc.fcisolver.spin_square(mc.ci, ncas, nelecas)
    oxygen_mask = mol.atom_charges() == 8
    oxygen_charges = np.asarray(charges)[oxygen_mask]

    summary = {
        "lambda": lam,
        "direction": args.direction,
        "status": "completed",
        "converged": True,
        "reference_checkpoint": str(Path(args.reference_chk).resolve()),
        "checkpoint": str(checkpoint_path.resolve()),
        "pyscf_log": str(log_path.resolve()),
        "energy_hartree": float(mc.e_tot),
        "rhf_energy_hartree": float(mf.e_tot),
        "rhf_converged": bool(mf.converged),
        "os_o_distance_bohr": os_o_bohr,
        "os_o_distance_angstrom": os_o_bohr * 0.529177210903,
        "coordinates_bohr": coords_bohr.tolist(),
        "ncore": ncore,
        "ncas": ncas,
        "nelecas": list(nelecas),
        "active_orbital_indices_one_based": list(range(ncore + 1, ncore + ncas + 1)),
        "active_irrep_counts": dict(final_counts),
        "natural_occupations": occ.tolist(),
        "spin_square": float(s2),
        "spin_multiplicity": float(multiplicity),
        "mulliken_atomic_charges": np.asarray(charges).tolist(),
        "oxygen_charges": oxygen_charges.tolist(),
        "oxygen_charge_spread": float(np.ptp(oxygen_charges)),
        "dipole_debye": np.asarray(dipole).tolist(),
        "dipole_norm_debye": float(np.linalg.norm(dipole)),
        "transport": transport,
        "previous_to_initial_guess": guess_metrics,
        "previous_to_optimized": consecutive,
        "initial_guess_to_optimized": initial_to_final,
    }
    write_json(summary_path, summary)
    print(
        "POINT_DONE "
        f"lambda={lam:.3f} E={mc.e_tot:.12f} "
        f"min_sv={consecutive['min_singular_value']:.8f} "
        f"max_angle={consecutive['max_principal_angle_deg']:.4f}deg "
        f"O_charge_spread={summary['oxygen_charge_spread']:.3e} "
        f"dipole={summary['dipole_norm_debye']:.3e}D",
        flush=True,
    )
    return mol, final_mo, summary


def main() -> int:
    args = parse_args()
    points = args.points if args.points is not None else DEFAULT_POINTS[args.direction]
    validate_points(args.direction, points)
    ref_chk = Path(args.reference_chk).expanduser().resolve()
    if not ref_chk.is_file():
        raise FileNotFoundError(f"Reference checkpoint not found: {ref_chk}")

    ref_mol, ref_record, ref_mo, ncore, ncas, nelecas = load_mc_state(ref_chk)
    if ref_mol.groupname != "D2":
        raise RuntimeError(
            f"Reference checkpoint working group is {ref_mol.groupname}; expected D2"
        )
    ref_summary = make_reference_summary(ref_mol, ref_record, ref_mo, ncore, ncas)

    output_root = Path(args.output_root).expanduser().resolve()
    direction_root = output_root / args.direction
    direction_root.mkdir(parents=True, exist_ok=True)
    write_json(direction_root / "reference_lambda_1.json", ref_summary)
    write_json(
        direction_root / "run_config.json",
        {
            "direction": args.direction,
            "points": points,
            "reference_checkpoint": str(ref_chk),
            "ncore": ncore,
            "ncas": ncas,
            "nelecas": list(nelecas),
            "active_irrep_counts_expected": dict(ACTIVE_IRREPS_EXPECTED),
            "omp_num_threads": os.environ.get("OMP_NUM_THREADS"),
            "mkl_num_threads": os.environ.get("MKL_NUM_THREADS"),
            "memory_mb": args.memory_mb,
            "fci_memory_mb": args.fci_memory_mb,
            "min_consecutive_sv": args.min_consecutive_sv,
        },
    )

    print(
        f"REFERENCE_OK chk={ref_chk} group={ref_mol.groupname} "
        f"ncore={ncore} ncas={ncas} nelecas={nelecas}",
        flush=True,
    )
    prev_mol, prev_mo = ref_mol, ref_mo
    for lam in points:
        point_dir = direction_root / lambda_tag(lam)
        try:
            prev_mol, prev_mo, _ = run_point(
                args,
                lam,
                ref_mol,
                prev_mol,
                prev_mo,
                ncore,
                ncas,
                nelecas,
                point_dir,
            )
        except Exception as exc:
            point_dir.mkdir(parents=True, exist_ok=True)
            write_json(
                point_dir / "failure.json",
                {
                    "lambda": lam,
                    "direction": args.direction,
                    "converged": False,
                    "error": str(exc),
                    "traceback": traceback.format_exc(),
                },
            )
            print(f"POINT_FAILED lambda={lam:.3f}: {exc}", file=sys.stderr, flush=True)
            raise
    print(f"DIRECTION_DONE {args.direction} points={points}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
