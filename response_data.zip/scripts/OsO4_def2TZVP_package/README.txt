OsO4 CASSCF(24,17)/def2-TZVP production package

Copy this directory to /scr/zdb/lambda_1_symmetry and run from that parent.
Do not overwrite or rename the old def2-SVP checkpoint.

1. Build and audit the lambda=1 def2-TZVP reference:
   nohup env STAGE=reference THREADS=32 bash OsO4_def2TZVP_package/run_OsO4_def2TZVP_production.sh > launch_reference.log 2>&1 &

2. After the reference prints status PASS, run the continuous zero-field branch:
   nohup env STAGE=zero THREADS=32 bash OsO4_def2TZVP_package/run_OsO4_def2TZVP_production.sh > launch_zero.log 2>&1 &

3. After zero field finishes, test one finite-field point near the minimum:
   nohup env STAGE=field-smoke THREADS=32 bash OsO4_def2TZVP_package/run_OsO4_def2TZVP_production.sh > launch_field_smoke.log 2>&1 &

4. Only after the smoke audit passes, run all selected finite-field points:
   nohup env STAGE=field THREADS=32 bash OsO4_def2TZVP_package/run_OsO4_def2TZVP_production.sh > launch_field.log 2>&1 &

Monitor:
   tail -f OsO4_def2TZVP_reference.stdout
   tail -f OsO4_def2TZVP_zero.stdout
   tail -f OsO4_def2TZVP_field_smoke.stdout

The zero scan includes intermediate 0.025 steps to protect active-space identity.
The publication grid remains 0.650, 0.675, 0.700, 0.725, 0.750, 0.800,
0.850, 0.900, 0.950, and 1.000. Intermediate checkpoints are continuation aids.
