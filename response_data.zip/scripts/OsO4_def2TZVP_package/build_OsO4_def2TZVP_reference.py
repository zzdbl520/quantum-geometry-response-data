#!/usr/bin/env python3
"""Migrate the validated OsO4 CAS(24,17) state to def2-TZVP/def2-ECP."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

import numpy as np
from pyscf import gto, lib, mcscf, scf, symm
from pyscf.mcscf import chkfile as mc_chkfile

NCORE, NCAS, NELECAS = 12, 17, (12, 12)
EXPECTED_D2 = Counter({"A": 5, "B1": 4, "B2": 4, "B3": 4})


def args():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--source-chk", default="lambda_1_CAS24fullvalence_D2_A.chk")
    p.add_argument("--output-chk", default="lambda_1_CAS24_def2TZVP_D2_A.chk")
    p.add_argument("--output-log", default="lambda_1_CAS24_def2TZVP_D2_A.out")
    p.add_argument("--summary", default="lambda_1_CAS24_def2TZVP_D2_A_summary.json")
    p.add_argument("--memory-mb", type=int, default=500000)
    p.add_argument("--fci-memory-mb", type=int, default=400000)
    p.add_argument("--scf-max-cycle", type=int, default=300)
    p.add_argument("--macro-max-cycle", type=int, default=300)
    p.add_argument("--overwrite", action="store_true")
    return p.parse_args()


def invsqrt(metric, label):
    metric = 0.5 * (metric + metric.T.conj())
    w, v = np.linalg.eigh(metric)
    if w.min() < 1e-10:
        raise RuntimeError(f"{label} projection is rank deficient: min eig={w.min():.3e}")
    return (v * w**-0.5) @ v.T.conj(), w


def orth(block, s, label):
    x, w = invsqrt(block.T.conj() @ s @ block, label)
    return block @ x, w


def remove(block, space, s):
    return block - space @ (space.T.conj() @ s @ block)


def labels(mol, mo, s):
    ids = np.asarray(symm.label_orb_symm(mol, mol.irrep_id, mol.symm_orb, mo,
                                         s=s, check=True), dtype=int)
    names = {int(i): str(n) for i, n in zip(mol.irrep_id, mol.irrep_name)}
    return ids, [names[int(i)] for i in ids]


def make_new_mol(old, log):
    mol = gto.Mole()
    mol.atom = [(old.atom_symbol(i), tuple(old.atom_coord(i))) for i in range(old.natm)]
    mol.unit = "Bohr"
    mol.charge = old.charge
    mol.spin = old.spin
    mol.basis = "def2-tzvp"
    mol.ecp = {"Os": "def2-tzvp"}
    mol.symmetry = True
    mol.symmetry_subgroup = "D2"
    mol.verbose = 4
    mol.output = str(Path(log).resolve())
    mol.build(dump_input=False, parse_arg=False)
    if mol.groupname != "D2":
        raise RuntimeError(f"new-basis working group is {mol.groupname}, expected D2")
    return mol


def main():
    a = args()
    source, target = Path(a.source_chk).resolve(), Path(a.output_chk).resolve()
    if target.exists() and not a.overwrite:
        raise FileExistsError(f"Target exists: {target}; use --overwrite only deliberately")
    old, rec = mc_chkfile.load_mcscf(str(source))
    old_mo = np.asarray(rec["mo_coeff"])
    state = (int(np.asarray(rec["ncore"]).ravel()[0]),
             int(np.asarray(rec["ncas"]).ravel()[0]),
             tuple(int(x) for x in np.asarray(rec["nelecas"]).ravel()))
    if state != (NCORE, NCAS, NELECAS):
        raise RuntimeError(f"source state is {state}, expected {(NCORE, NCAS, NELECAS)}")

    mol = make_new_mol(old, a.output_log)
    mf = scf.RHF(mol)
    mf.max_memory = a.memory_mb
    mf.max_cycle = a.scf_max_cycle
    mf.conv_tol = 1e-12
    mf.conv_tol_grad = 1e-8
    mf.chkfile = str(target.with_name(target.stem + "_RHF.chk"))
    mf.kernel()
    if not mf.converged:
        newton = mf.newton()
        newton.max_cycle = 100
        newton.conv_tol = 1e-12
        newton.conv_tol_grad = 1e-8
        newton.kernel(mf.mo_coeff, mf.mo_occ)
        mf = newton
    if not mf.converged:
        raise RuntimeError("def2-TZVP RHF failed after DIIS and Newton")

    s = mol.intor_symmetric("int1e_ovlp")
    cross = gto.intor_cross("int1e_ovlp", mol, old)
    projected = np.linalg.solve(s, cross @ old_mo[:, :NCORE + NCAS])
    active, active_w = orth(projected[:, NCORE:], s, "active")
    core, core_w = orth(remove(projected[:, :NCORE], active, s), s, "core")
    occupied = np.hstack((core, active))
    # Remove the occupied span from the complete new-basis RHF MO set.  The
    # result is intentionally rank deficient by NCORE+NCAS; diagonalize its
    # metric and retain only the nonzero complement.
    q = remove(np.asarray(mf.mo_coeff), occupied, s)
    metric = 0.5 * (q.T @ s @ q + (q.T @ s @ q).T)
    w, v = np.linalg.eigh(metric)
    keep = w > 1e-8
    q = q @ (v[:, keep] * w[keep]**-0.5)
    nvirt = mol.nao_nr() - NCORE - NCAS
    if q.shape[1] != nvirt:
        raise RuntimeError(f"virtual complement has {q.shape[1]} columns; expected {nvirt}")

    blocks = []
    for block in (core, active, q):
        blocks.append(symm.symmetrize_space(mol, block, s=s, check=True))
    mo0 = np.hstack(blocks)
    ids, names = labels(mol, mo0, s)
    counts = Counter(names[NCORE:NCORE+NCAS])
    if counts != EXPECTED_D2:
        raise RuntimeError(f"projected active irreps {dict(counts)}; expected {dict(EXPECTED_D2)}")
    mo0 = lib.tag_array(mo0, orbsym=ids)

    mc = mcscf.CASSCF(mf, NCAS, NELECAS, ncore=NCORE)
    mc.max_memory = a.memory_mb
    mc.fcisolver.max_memory = a.fci_memory_mb
    mc.fcisolver.pspace_size = 1200
    mc.fcisolver.max_cycle = 400
    mc.fcisolver.wfnsym = "A"
    mc.natorb = True
    mc.canonicalization = True
    mc.max_cycle_macro = a.macro_max_cycle
    mc.max_cycle_micro = 8
    mc.max_stepsize = 0.02
    mc.conv_tol = 1e-8
    mc.chkfile = str(target)
    mc.kernel(mo0)
    if not mc.converged:
        raise RuntimeError("def2-TZVP CAS(24,17) reference did not converge")

    final = np.asarray(mc.mo_coeff)
    ids_f, names_f = labels(mol, final, s)
    final_counts = Counter(names_f[NCORE:NCORE+NCAS])
    sv = np.linalg.svd(mo0[:, NCORE:NCORE+NCAS].T @ s @
                       final[:, NCORE:NCORE+NCAS], compute_uv=False)
    dm1a = mc.fcisolver.make_rdm1(mc.ci, NCAS, NELECAS)
    occ = np.linalg.eigvalsh(0.5*(dm1a+dm1a.T))[::-1]
    s2, mult = mc.fcisolver.spin_square(mc.ci, NCAS, NELECAS)
    summary = {
        "status": "PASS", "basis": "def2-TZVP", "os_ecp": "def2-TZVP",
        "source_checkpoint": str(source), "checkpoint": str(target),
        "old_nao": old.nao_nr(), "new_nao": mol.nao_nr(),
        "energy_hartree": float(mc.e_tot), "ncore": NCORE, "ncas": NCAS,
        "nelecas": list(NELECAS), "active_irrep_counts": dict(final_counts),
        "source_projection_active_min_eigenvalue": float(active_w.min()),
        "source_projection_core_min_eigenvalue": float(core_w.min()),
        "initial_to_final_active_min_sv": float(sv.min()),
        "natural_occupations": occ.tolist(), "spin_square": float(s2),
        "spin_multiplicity": float(mult),
    }
    if final_counts != EXPECTED_D2 or sv.min() < 0.70 or abs(s2) > 1e-6:
        summary["status"] = "FAIL"
    Path(a.summary).write_text(json.dumps(summary, indent=2, sort_keys=True)+"\n")
    print(json.dumps(summary, indent=2, sort_keys=True))
    if summary["status"] != "PASS":
        raise RuntimeError("reference audit failed")


if __name__ == "__main__":
    main()
