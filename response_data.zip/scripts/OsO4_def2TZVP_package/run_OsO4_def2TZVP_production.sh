#!/usr/bin/env bash
set -euo pipefail

ROOT=${ROOT:-$(pwd)}
PKG=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
PYTHON=${PYTHON:-python}
THREADS=${THREADS:-32}
MEMORY_MB=${MEMORY_MB:-500000}
FCI_MEMORY_MB=${FCI_MEMORY_MB:-400000}
STAGE=${STAGE:-reference}
SOURCE_CHK=${SOURCE_CHK:-lambda_1_CAS24fullvalence_D2_A.chk}
REFERENCE_CHK=${REFERENCE_CHK:-lambda_1_CAS24_def2TZVP_D2_A.chk}
ZERO_ROOT=${ZERO_ROOT:-OsO4_CAS24_def2TZVP_zero}
FF_ROOT=${FF_ROOT:-OsO4_CAS24_def2TZVP_F1em3}

export OMP_NUM_THREADS=$THREADS
export MKL_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=$THREADS
cd "$ROOT"

case "$STAGE" in
  reference)
    "$PYTHON" -u "$PKG/build_OsO4_def2TZVP_reference.py" \
      --source-chk "$SOURCE_CHK" --output-chk "$REFERENCE_CHK" \
      --memory-mb "$MEMORY_MB" --fci-memory-mb "$FCI_MEMORY_MB" \
      2>&1 | tee OsO4_def2TZVP_reference.stdout
    ;;
  zero)
    [[ -f "$REFERENCE_CHK" ]] || { echo "STOP: missing $REFERENCE_CHK" >&2; exit 2; }
    # One continuous branch from lambda=1; fine steps are intentional.
    "$PYTHON" -u "$PKG/OsO4_CAS24fullvalence_pilot_scan.py" \
      --direction compression \
      --points 0.975 0.950 0.925 0.900 0.875 0.850 0.825 0.800 0.775 0.750 0.725 0.700 0.675 0.650 \
      --reference-chk "$REFERENCE_CHK" --output-root "$ZERO_ROOT" \
      --memory-mb "$MEMORY_MB" --fci-memory-mb "$FCI_MEMORY_MB" \
      --scf-max-cycle 400 --macro-max-cycle 300 --scf-conv-tol-grad 1e-7 \
      2>&1 | tee OsO4_def2TZVP_zero.stdout
    ;;
  field-smoke)
    "$PYTHON" -u "$PKG/OsO4_CAS24fullvalence_finite_field_robust.py" \
      --mode compression --points 0.700 --field 1e-3 --axis z \
      --reference-chk "$REFERENCE_CHK" --zero-root "$ZERO_ROOT" --output-root "$FF_ROOT" \
      --memory-mb "$MEMORY_MB" --fci-memory-mb "$FCI_MEMORY_MB" \
      --scf-max-cycle 200 --scf-newton-max-cycle 100 --macro-max-cycle 300 \
      2>&1 | tee OsO4_def2TZVP_field_smoke.stdout
    "$PYTHON" "$PKG/analyze_OsO4_CAS24fullvalence_finite_field.py" \
      --root "$FF_ROOT" --expected-points 0.700
    ;;
  field)
    "$PYTHON" -u "$PKG/OsO4_CAS24fullvalence_finite_field_robust.py" \
      --mode compression --points 0.650 0.675 0.700 0.725 0.750 0.800 0.850 0.900 0.950 1.000 \
      --field 1e-3 --axis z --reference-chk "$REFERENCE_CHK" \
      --zero-root "$ZERO_ROOT" --output-root "$FF_ROOT" \
      --memory-mb "$MEMORY_MB" --fci-memory-mb "$FCI_MEMORY_MB" \
      --scf-max-cycle 200 --scf-newton-max-cycle 100 --macro-max-cycle 300 \
      2>&1 | tee OsO4_def2TZVP_field.stdout
    "$PYTHON" "$PKG/analyze_OsO4_CAS24fullvalence_finite_field.py" \
      --root "$FF_ROOT" --expected-points 0.650 0.675 0.700 0.725 0.750 0.800 0.850 0.900 0.950 1.000
    ;;
  *) echo "STAGE must be reference, zero, field-smoke, or field" >&2; exit 2 ;;
esac
