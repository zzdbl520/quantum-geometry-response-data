#!/usr/bin/env python3
"""Collect and validate finite-field OsO4 CAS(24,17) polarizabilities."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np


MODES = {
    "smoke": {1.00},
    "compression": {0.80, 0.85, 0.90, 0.95, 1.00},
    "stretch": {1.00, 1.05, 1.10, 1.15, 1.20},
    "all": {0.80, 0.85, 0.90, 0.95, 1.00, 1.05, 1.10, 1.15, 1.20},
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default="OsO4_CAS24fullvalence_finite_field_C2v_F1em3")
    parser.add_argument("--mode", choices=tuple(MODES), default="all")
    parser.add_argument("--expected-points", nargs="+", type=float)
    parser.add_argument("--min-sv", type=float, default=0.70)
    parser.add_argument("--max-pm-energy-difference", type=float, default=1.0e-7)
    parser.add_argument("--max-pm-occ-difference", type=float, default=1.0e-4)
    parser.add_argument("--max-field-energy-shift", type=float, default=5.0e-3)
    args = parser.parse_args()

    root = Path(args.root).expanduser().resolve()
    rows = []
    failures = []
    for path in sorted(root.glob("lambda_*/polarizability.json")):
        data = json.loads(path.read_text())
        if data.get("field_working_group") != "C2v":
            failures.append(f"{path}: finite-field working group is not C2v")
        row = {
            "lambda": float(data["lambda"]),
            "field_au": float(data["field_magnitude_au"]),
            "alpha_iso_au": float(data["alpha_iso_au"]),
            "zero_energy_hartree": float(data["zero_energy_hartree"]),
            "plus_energy_hartree": float(data["plus_energy_hartree"]),
            "minus_energy_hartree": float(data["minus_energy_hartree"]),
            "plus_minus_energy_difference_hartree": float(
                data["plus_minus_energy_difference_hartree"]
            ),
            "plus_minus_max_occ_difference": float(
                data["plus_minus_max_natural_occupation_difference"]
            ),
            "plus_min_active_sv": float(data["plus_min_active_sv"]),
            "minus_min_active_sv": float(data["minus_min_active_sv"]),
            "max_abs_field_energy_shift_hartree": max(
                abs(float(data["plus_energy_hartree"]) - float(data["zero_energy_hartree"])),
                abs(float(data["minus_energy_hartree"]) - float(data["zero_energy_hartree"])),
            ),
            "summary": str(path),
        }
        rows.append(row)
        if not np.isfinite(row["alpha_iso_au"]) or row["alpha_iso_au"] <= 0.0:
            failures.append(f"lambda={row['lambda']:.3f}: invalid alpha")
        if min(row["plus_min_active_sv"], row["minus_min_active_sv"]) < args.min_sv:
            failures.append(f"lambda={row['lambda']:.3f}: active-space continuity failure")
        if abs(row["plus_minus_energy_difference_hartree"]) > args.max_pm_energy_difference:
            failures.append(f"lambda={row['lambda']:.3f}: +F/-F energy symmetry failure")
        if row["plus_minus_max_occ_difference"] > args.max_pm_occ_difference:
            failures.append(f"lambda={row['lambda']:.3f}: +F/-F occupation symmetry failure")
        if row["max_abs_field_energy_shift_hartree"] > args.max_field_energy_shift:
            failures.append(f"lambda={row['lambda']:.3f}: probable finite-field branch change")

    rows.sort(key=lambda item: item["lambda"])
    fields = {round(row["field_au"], 15) for row in rows}
    if len(fields) > 1:
        failures.append(f"mixed field magnitudes in one output root: {sorted(fields)}")
    found = {round(row["lambda"], 8) for row in rows}
    expected = (
        {round(x, 8) for x in args.expected_points}
        if args.expected_points
        else MODES[args.mode]
    )
    missing = sorted(expected - found)
    if missing:
        failures.append(f"missing finite-field points: {missing}")

    csv_path = root / "polarizability_summary.csv"
    if rows:
        with csv_path.open("w", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)

    report = {
        "pass": not failures,
        "completed_points": sorted(found),
        "missing_points": missing,
        "failures": failures,
        "summary_csv": str(csv_path),
    }
    (root / "finite_field_validation.json").write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n"
    )
    print(json.dumps(report, indent=2, sort_keys=True))
    if rows:
        print("\n lambda       alpha_iso/a.u.      minSV       E(+F)-E(-F)/Eh")
        for row in rows:
            print(
                f" {row['lambda']:6.3f}  {row['alpha_iso_au']:18.10f}  "
                f"{min(row['plus_min_active_sv'], row['minus_min_active_sv']):.8f}  "
                f"{row['plus_minus_energy_difference_hartree']: .3e}"
            )
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
