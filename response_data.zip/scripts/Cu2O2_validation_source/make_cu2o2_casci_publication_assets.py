#!/usr/bin/env python3
"""Create publication figures and an independent audit for Cu2O2 CASCI validation."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np


SOURCE_COLOR = "#777777"
PARENT_COLOR = "#B23A2A"
ACCENT_COLOR = "#1F5A7A"


def load_rows(path: Path) -> list[dict[str, float | str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    converted: list[dict[str, float | str]] = []
    for row in rows:
        converted.append(
            {
                key: value if key == "point" else float(value)
                for key, value in row.items()
            }
        )
    return converted


def quadratic_diagnostics(x: np.ndarray, y: np.ndarray) -> dict[str, float]:
    a, b, c = np.polyfit(x, y, 2)
    vertex = -b / (2.0 * a)
    minimum = np.polyval((a, b, c), vertex)
    return {
        "a": float(a),
        "b": float(b),
        "c": float(c),
        "curvature_second_derivative": float(2.0 * a),
        "x": float(vertex),
        "y": float(minimum),
    }


def configure_style() -> None:
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Liberation Sans", "DejaVu Sans"],
            "font.size": 8.0,
            "axes.labelsize": 9.0,
            "axes.linewidth": 0.8,
            "xtick.labelsize": 7.5,
            "ytick.labelsize": 7.5,
            "xtick.direction": "in",
            "ytick.direction": "in",
            "xtick.major.width": 0.8,
            "ytick.major.width": 0.8,
            "xtick.major.size": 3.5,
            "ytick.major.size": 3.5,
            "legend.fontsize": 7.2,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "savefig.facecolor": "white",
            "figure.facecolor": "white",
        }
    )


def draw_response_panel(
    axis: mpl.axes.Axes,
    r: np.ndarray,
    source: np.ndarray,
    parent: np.ndarray,
    source_fit: dict[str, float],
    parent_fit: dict[str, float],
    *,
    compact: bool,
) -> None:
    grid = np.linspace(1.695, 1.805, 401)
    source_curve = np.polyval(
        (source_fit["a"], source_fit["b"], source_fit["c"]), grid
    )
    parent_curve = np.polyval(
        (parent_fit["a"], parent_fit["b"], parent_fit["c"]), grid
    )

    axis.plot(
        grid,
        source_curve,
        color=SOURCE_COLOR,
        linewidth=1.45,
        linestyle=(0, (4, 2.4)),
        label="CASSCF(8e,6o)",
        zorder=2,
    )
    axis.scatter(
        r,
        source,
        s=24 if compact else 28,
        facecolor="white",
        edgecolor=SOURCE_COLOR,
        linewidth=1.25,
        zorder=4,
    )
    axis.plot(
        grid,
        parent_curve,
        color=PARENT_COLOR,
        linewidth=1.55,
        label="parent CASCI(28e,16o)",
        zorder=3,
    )
    axis.scatter(
        r,
        parent,
        s=25 if compact else 29,
        facecolor=PARENT_COLOR,
        edgecolor=PARENT_COLOR,
        linewidth=0.8,
        zorder=5,
    )

    y_floor = min(source_fit["y"], parent_fit["y"]) - 0.012
    axis.vlines(
        source_fit["x"],
        y_floor,
        source_fit["y"],
        color=SOURCE_COLOR,
        linewidth=0.9,
        linestyle=(0, (2.0, 2.0)),
        zorder=1,
    )
    axis.vlines(
        parent_fit["x"],
        y_floor,
        parent_fit["y"],
        color=PARENT_COLOR,
        linewidth=0.9,
        linestyle=(0, (2.0, 2.0)),
        zorder=1,
    )
    axis.scatter(
        [source_fit["x"]],
        [source_fit["y"]],
        marker="v",
        s=20,
        facecolor="white",
        edgecolor=SOURCE_COLOR,
        linewidth=1.0,
        zorder=6,
    )
    axis.scatter(
        [parent_fit["x"]],
        [parent_fit["y"]],
        marker="v",
        s=20,
        facecolor=PARENT_COLOR,
        edgecolor=PARENT_COLOR,
        linewidth=0.8,
        zorder=6,
    )

    shift = abs(parent_fit["x"] - source_fit["x"])
    axis.text(
        0.04,
        0.06,
        rf"$|\Delta R_{{\min}}|={shift:.4f}$ Å",
        transform=axis.transAxes,
        ha="left",
        va="bottom",
        fontsize=7.2,
        color="#222222",
        bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.88, "pad": 1.0},
    )
    axis.set_xlim(1.695, 1.805)
    axis.set_ylim(108.34, 108.77)
    axis.set_xticks([1.70, 1.75, 1.80])
    axis.set_xlabel(r"$R_{\mathrm{O-O}}$ (Å)")
    axis.set_ylabel(r"$\alpha_{xx}$ (a.u.)")
    axis.legend(loc="upper right", frameon=False, handlelength=2.5)
    axis.tick_params(top=True, right=True)


def save_figure(figure: mpl.figure.Figure, pdf: Path, png: Path) -> None:
    pdf.parent.mkdir(parents=True, exist_ok=True)
    png.parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(pdf, bbox_inches="tight", pad_inches=0.025)
    figure.savefig(png, dpi=600, bbox_inches="tight", pad_inches=0.025)
    plt.close(figure)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    summary_path = args.input / "results" / "PARENT_CASCI2816_LOCAL_SUMMARY.json"
    csv_path = args.input / "results" / "PARENT_CASCI2816_LOCAL_RESPONSE.csv"
    preflight_path = args.input / "work" / "PREFLIGHT.json"
    production_path = args.input / "work" / "PRODUCTION.json"
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    preflight = json.loads(preflight_path.read_text(encoding="utf-8"))
    production = json.loads(production_path.read_text(encoding="utf-8"))
    rows = load_rows(csv_path)

    r = np.asarray([row["R_OO_A"] for row in rows], dtype=float)
    source = np.asarray(
        [row["source_CAS86_alpha_energy_five_au"] for row in rows], dtype=float
    )
    parent = np.asarray(
        [row["parent_CASCI2816_alpha_energy_five_au"] for row in rows], dtype=float
    )
    source_fit = quadratic_diagnostics(r, source)
    parent_fit = quadratic_diagnostics(r, parent)
    reported_source = summary["extrema"]["source_CAS86"]
    reported_parent = summary["extrema"]["parent_CASCI2816"]

    for key in ("a", "b", "c", "curvature_second_derivative", "x", "y"):
        if not np.isclose(source_fit[key], reported_source[key], rtol=0.0, atol=2e-10):
            raise RuntimeError(f"source fit mismatch for {key}")
        if not np.isclose(parent_fit[key], reported_parent[key], rtol=0.0, atol=2e-10):
            raise RuntimeError(f"parent fit mismatch for {key}")
    hashes = {
        summary["protocol_hash"],
        preflight["protocol_hash"],
        production["protocol_hash"],
    }
    if len(hashes) != 1:
        raise RuntimeError("protocol hashes do not agree")
    if summary["decision"] != "PARENT_CASCI2816_LOCAL_MINIMUM_VALIDATED":
        raise RuntimeError("validation decision is not the strongest PASS state")
    if preflight["status"] != "PASS" or production["status"] != "COMPLETE":
        raise RuntimeError("preflight or production status is incomplete")
    if not all(summary["hard_gates"].values()):
        raise RuntimeError("one or more hard gates failed")
    if not all(summary["preferred_gates"].values()):
        raise RuntimeError("one or more preferred gates failed")

    correction = parent - source
    relative_correction_percent = 100.0 * correction / source
    energy_lowering_kcal = np.asarray(
        [
            (row["parent_CASCI2816_energy_zero_Eh"] - row["source_CAS86_energy_zero_Eh"])
            * 627.5094740631
            for row in rows
        ],
        dtype=float,
    )
    response = summary["response_diagnostics"]
    shift = abs(parent_fit["x"] - source_fit["x"])
    audit = {
        "status": "PASS_INDEPENDENT_RECALCULATION",
        "decision": summary["decision"],
        "protocol_hash": next(iter(hashes)),
        "states_completed": len(production["available_states"]),
        "source_fit_recalculated": source_fit,
        "parent_fit_recalculated": parent_fit,
        "absolute_vertex_shift_A": shift,
        "vertex_shift_as_percent_of_0.05_A_grid": 100.0 * shift / 0.05,
        "curvature_relative_change_percent": 100.0
        * (parent_fit["curvature_second_derivative"] / source_fit["curvature_second_derivative"] - 1.0),
        "alpha_correction_au": correction.tolist(),
        "alpha_relative_correction_percent": relative_correction_percent.tolist(),
        "parent_minus_source_zero_field_energy_kcal_per_mol": energy_lowering_kcal.tolist(),
        "response_diagnostics": response,
        "all_hard_gates_pass": all(summary["hard_gates"].values()),
        "all_preferred_gates_pass": all(summary["preferred_gates"].values()),
    }
    audit_dir = args.output / "audit"
    audit_dir.mkdir(parents=True, exist_ok=True)
    (audit_dir / "Cu2O2_CAS2816_independent_audit.json").write_text(
        json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    configure_style()
    main_figure, main_axis = plt.subplots(figsize=(3.46, 2.62))
    draw_response_panel(
        main_axis, r, source, parent, source_fit, parent_fit, compact=True
    )
    save_figure(
        main_figure,
        args.output / "pdf" / "Figure_Cu2O2_CAS2816_validation_main.pdf",
        args.output / "png" / "Figure_Cu2O2_CAS2816_validation_main.png",
    )

    si_figure, (left, right) = plt.subplots(1, 2, figsize=(7.08, 2.75))
    draw_response_panel(left, r, source, parent, source_fit, parent_fit, compact=False)
    left.text(
        -0.17,
        1.04,
        "a",
        transform=left.transAxes,
        fontsize=10,
        fontweight="bold",
        va="top",
    )

    correction_fit = np.polyfit(r, correction, 1)
    correction_grid = np.linspace(1.695, 1.805, 201)
    right.plot(
        correction_grid,
        np.polyval(correction_fit, correction_grid),
        color=ACCENT_COLOR,
        linewidth=1.5,
        zorder=2,
    )
    right.scatter(
        r,
        correction,
        s=29,
        facecolor=ACCENT_COLOR,
        edgecolor=ACCENT_COLOR,
        linewidth=0.8,
        zorder=3,
    )
    for index, (x_value, y_value, percentage) in enumerate(
        zip(r, correction, relative_correction_percent)
    ):
        if index == 0:
            offset = (5, 7)
            alignment = "left"
        elif index == len(r) - 1:
            offset = (-5, 7)
            alignment = "right"
        else:
            offset = (0, 7)
            alignment = "center"
        right.annotate(
            f"{percentage:.3f}%",
            (x_value, y_value),
            xytext=offset,
            textcoords="offset points",
            ha=alignment,
            va="bottom",
            fontsize=7.0,
            color="#333333",
        )
    right.set_xlim(1.695, 1.805)
    right.set_ylim(0.095, 0.160)
    right.set_xticks([1.70, 1.75, 1.80])
    right.set_xlabel(r"$R_{\mathrm{O-O}}$ (Å)")
    right.set_ylabel(r"$\Delta\alpha_{xx}$ (a.u.)")
    right.tick_params(top=True, right=True)
    right.text(
        0.04,
        0.94,
        "parent CASCI(28e,16o) - CASSCF(8e,6o)",
        transform=right.transAxes,
        ha="left",
        va="top",
        fontsize=7.2,
        color=ACCENT_COLOR,
    )
    right.text(
        -0.17,
        1.04,
        "b",
        transform=right.transAxes,
        fontsize=10,
        fontweight="bold",
        va="top",
    )
    si_figure.subplots_adjust(left=0.085, right=0.985, bottom=0.20, top=0.97, wspace=0.31)
    save_figure(
        si_figure,
        args.output / "pdf" / "Figure_SI_Cu2O2_CAS2816_validation.pdf",
        args.output / "png" / "Figure_SI_Cu2O2_CAS2816_validation.png",
    )

    print(json.dumps(audit, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
