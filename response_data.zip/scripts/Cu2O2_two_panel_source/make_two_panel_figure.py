#!/usr/bin/env python3
"""Two-panel publication figure for the Cu2O2 response reversal."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parent
HARTREE_TO_KCAL_MOL = 627.509474

INK = "#202124"
BLUE = "#1675B6"
RED = "#C53D2D"
AMBER = "#E69F00"
GREY = "#6B7280"
LIGHT_GREY = "#D8DDE5"
PALE_GOLD = "#F4D06F"


def read_csv(name: str) -> list[dict[str, str]]:
    with (ROOT / name).open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def local_vertex(x: np.ndarray, y: np.ndarray, mode: str) -> tuple[float, float]:
    i = int(np.argmin(y) if mode == "min" else np.argmax(y))
    if i == 0 or i == len(x) - 1:
        raise RuntimeError(f"{mode}imum is at a scan endpoint")
    coeff = np.polyfit(x[i - 1 : i + 2], y[i - 1 : i + 2], 2)
    xv = float(-coeff[1] / (2.0 * coeff[0]))
    return xv, float(np.polyval(coeff, xv))


def local_value(x: np.ndarray, y: np.ndarray, xv: float) -> float:
    """Evaluate the local three-point quadratic centered nearest to xv."""
    i = int(np.argmin(np.abs(x - xv)))
    if i == 0 or i == len(x) - 1:
        raise RuntimeError("interpolation point is at a scan endpoint")
    coeff = np.polyfit(x[i - 1 : i + 2], y[i - 1 : i + 2], 2)
    return float(np.polyval(coeff, xv))


def style_axis(ax: mpl.axes.Axes) -> None:
    ax.tick_params(axis="both", which="major", direction="in", length=3.6,
                   width=0.85, pad=2.7, top=True, right=True)
    for spine in ax.spines.values():
        spine.set_linewidth(0.9)


def panel_label(ax: mpl.axes.Axes, label: str) -> None:
    ax.text(-0.14, 1.075, label, transform=ax.transAxes, fontsize=12,
            fontweight="bold", ha="left", va="top")


def main() -> None:
    response = read_csv("DEF2TZVP_25POINT_RESPONSE_POINTS.csv")
    metric = read_csv("DEF2TZVP_FIELD_QMETRIC.csv")

    x = np.asarray([float(row["O_O_A"]) for row in metric])
    energy = np.asarray([float(row["zero_energy_Eh"]) for row in response])
    alpha = np.asarray([float(row["alpha_xx_energy_au"]) for row in metric])
    gff = np.asarray([float(row["g_FxFx_FS_au"]) for row in metric])
    delta = np.asarray([float(row["Delta_geom_x_eV"]) for row in metric])

    r_pes, e_min = local_vertex(x, energy, "min")
    r_alpha, alpha_min = local_vertex(x, alpha, "min")
    r_gff, _ = local_vertex(x, gff, "min")
    r_delta, _ = local_vertex(x, delta, "max")
    e_rel = (energy - e_min) * HARTREE_TO_KCAL_MOL

    # Normalize all three mechanism curves at the same continuous response
    # minimum used in panel (a), rather than at the nearest discrete grid point.
    iref = int(np.argmin(np.abs(x - r_alpha)))
    g_norm = gff / local_value(x, gff, r_alpha)
    d_norm = delta / local_value(x, delta, r_alpha)
    a_norm = alpha / alpha_min

    mpl.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 8.2,
        "axes.labelsize": 8.7,
        "axes.titlesize": 9.4,
        "axes.titleweight": "bold",
        "xtick.labelsize": 7.6,
        "ytick.labelsize": 7.6,
        "legend.fontsize": 7.25,
        "axes.linewidth": 0.9,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
        "savefig.facecolor": "white",
    })

    fig, (ax_a, ax_b) = plt.subplots(1, 2, figsize=(7.15, 3.22))
    fig.subplots_adjust(left=0.082, right=0.945, bottom=0.19, top=0.88, wspace=0.42)

    # (a) Potential energy and longitudinal polarizability.
    ax_ar = ax_a.twinx()
    line_e, = ax_a.plot(x, e_rel, color=INK, marker="o", ms=3.25,
                        mfc=INK, mec=INK, lw=1.55,
                        label=r"$E-E_{\min}$", zorder=3)
    line_a, = ax_ar.plot(x, alpha, color=BLUE, marker="s", ms=3.1,
                         mfc=BLUE, mec=BLUE, lw=1.65,
                         label=r"$\alpha_{xx}$", zorder=3)
    ax_a.axvspan(r_pes, r_alpha, color=PALE_GOLD, alpha=0.17, lw=0, zorder=0)
    ax_a.axvline(r_pes, color=GREY, ls=(0, (1.4, 2.0)), lw=1.05)
    ax_a.axvline(r_alpha, color=RED, ls=(0, (4.0, 2.2)), lw=1.1)
    ax_a.scatter([r_pes], [0.0], marker="D", s=26, c=INK, zorder=5)
    ax_ar.scatter([r_alpha], [alpha_min], marker="v", s=43, c=RED,
                  edgecolor="white", linewidth=0.45, zorder=5)

    # Keep the extremum labels high in the panel and independent of either
    # y-scale so that neither annotation collides with its vertical guide.
    ax_a.text(r_pes - 0.040, 0.74, "PES min\n" + f"{r_pes:.3f} Å",
              transform=ax_a.get_xaxis_transform(),
              ha="right", va="bottom", color=INK, fontsize=7.1)
    ax_ar.text(r_alpha + 0.040, 0.74,
               r"$\alpha_{xx}$ min" + "\n" + f"{r_alpha:.3f} Å",
               transform=ax_ar.get_xaxis_transform(),
               ha="left", va="bottom", color=RED, fontsize=7.1)

    ax_a.set_xlim(1.27, 2.53)
    ax_a.set_ylim(-0.8, 31.0)
    ax_ar.set_ylim(120.0, 138.0)
    ax_ar.set_yticks(np.arange(120.0, 138.1, 2.0))
    ax_a.set_xlabel(r"$R_{\mathrm{O-O}}$ (Å)")
    ax_a.set_ylabel(r"Relative energy (kcal mol$^{-1}$)", color=INK)
    ax_ar.set_ylabel("Polarizability (a.u.)", color=BLUE)
    ax_ar.tick_params(axis="y", which="major", direction="in", length=3.6,
                      width=0.85, pad=2.7, colors=BLUE, right=True, left=False,
                      labelright=True, labelleft=False)
    ax_ar.tick_params(axis="x", top=False, bottom=False,
                      labeltop=False, labelbottom=False)
    ax_ar.spines["right"].set_color(BLUE)
    ax_a.legend([line_e, line_a], [line_e.get_label(), line_a.get_label()],
                loc="upper center", bbox_to_anchor=(0.64, 0.995),
                frameon=False, ncol=1, labelspacing=0.35,
                handlelength=1.9, handletextpad=0.55, borderaxespad=0.0)
    style_axis(ax_a)
    # The primary axis must not draw a second (black) scale on the twin-axis
    # side.  Only the blue polarizability axis is retained on the right.
    ax_a.tick_params(axis="y", right=False, labelright=False)
    ax_a.spines["right"].set_visible(False)
    ax_ar.spines["right"].set_visible(True)
    ax_ar.spines["right"].set_linewidth(0.9)
    for name in ("left", "top", "bottom"):
        ax_ar.spines[name].set_visible(False)
    panel_label(ax_a, "a")

    # (b) Metric-gap compensation mechanism.
    ax_b.plot(x, g_norm, color=BLUE, marker="o", ms=3.25, lw=1.65,
              label=r"$\widetilde g_{F_xF_x}$")
    ax_b.plot(x, d_norm, color=AMBER, marker="^", ms=3.65, lw=1.6,
              label=r"$\widetilde\Delta_{\rm geom}^{x}$")
    ax_b.plot(x, a_norm, color=RED, marker="D", ms=3.0, lw=1.7,
              label=r"$\widetilde\alpha_{xx}$")
    ax_b.axvspan(1.74, 1.76, color=RED, alpha=0.07, lw=0)
    ax_b.axvline(r_alpha, color=RED, ls=(0, (4.0, 2.2)), lw=1.05)
    ax_b.set_xlim(1.27, 2.53)
    ax_b.set_ylim(0.72, 1.54)
    ax_b.set_xlabel(r"$R_{\mathrm{O-O}}$ (Å)")
    ax_b.set_ylabel(r"Normalized at $\alpha_{xx}$ minimum")
    ax_b.legend(loc="upper left", frameon=False, ncol=1,
                bbox_to_anchor=(0.025, 0.985), handlelength=1.75,
                columnspacing=0.75, handletextpad=0.45, borderaxespad=0.0)
    ax_b.text(r_alpha - 0.014, 0.755, "response",
              ha="right", va="bottom", fontsize=6.8, color=RED)
    ax_b.text(r_alpha + 0.014, 0.755, "reversal",
              ha="left", va="bottom", fontsize=6.8, color=RED)
    style_axis(ax_b)
    panel_label(ax_b, "b")

    stem = ROOT / "Cu2O2_def2TZVP_energy_polar_mechanism_v1"
    fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight", pad_inches=0.03)
    fig.savefig(stem.with_suffix(".svg"), bbox_inches="tight", pad_inches=0.03)
    fig.savefig(stem.with_suffix(".png"), dpi=600,
                bbox_inches="tight", pad_inches=0.03)
    plt.close(fig)

    values = {
        "method": "orbital-relaxed state-specific singlet CASSCF(8e,6o)/def2-TZVP",
        "PES_minimum_A": r_pes,
        "alpha_xx_minimum_A": r_alpha,
        "PES_response_separation_A": r_alpha - r_pes,
        "field_metric_minimum_A": r_gff,
        "geometric_scale_maximum_A": r_delta,
        "extremum_estimator": "local_three_point_quadratic on 0.05-A grid",
        "normalization_reference": "local-quadratic values at fitted alpha_xx minimum",
        "normalization_reference_R_A": r_alpha,
        "normalization_nearest_grid_point": str(metric[iref]["point"]),
    }
    (ROOT / "FIGURE_VALUES.json").write_text(json.dumps(values, indent=2) + "\n")


if __name__ == "__main__":
    main()
