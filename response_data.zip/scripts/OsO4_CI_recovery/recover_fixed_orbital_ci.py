#!/usr/bin/env python3
"""Recover a CI vector by fixed-orbital CASCI from a converged CASSCF chk."""

from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path

import numpy as np
from pyscf import mcscf, scf
from pyscf.mcscf import chkfile as mc_chkfile


def load_driver(path: Path):
    spec = importlib.util.spec_from_file_location("oso4_ff_driver", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if not hasattr(module, "field_hamiltonian"):
        raise RuntimeError(f"{path} has no field_hamiltonian")
    return module


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--checkpoint", required=True)
    p.add_argument("--summary", required=True)
    p.add_argument("--driver", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--memory-mb", type=int, default=500000)
    p.add_argument("--fci-memory-mb", type=int, default=400000)
    p.add_argument("--energy-tolerance", type=float, default=5.0e-9)
    p.add_argument("--overwrite", action="store_true")
    args = p.parse_args()

    chk = Path(args.checkpoint).resolve()
    summary_path = Path(args.summary).resolve()
    out = Path(args.output_dir).resolve()
    out.mkdir(parents=True, exist_ok=True)
    result_path = out / "recovery.json"
    ci_path = out / "ci.npy"
    mo_path = out / "mo_coeff.npy"
    if result_path.is_file() and ci_path.is_file() and mo_path.is_file() and not args.overwrite:
        old = json.loads(result_path.read_text())
        if old.get("status") == "PASS":
            print(f"RECOVERY_RESUME {out}")
            return 0

    mol, rec = mc_chkfile.load_mcscf(str(chk))
    required = ("mo_coeff", "mo_occ", "ncore", "ncas", "nelecas", "e_tot")
    missing = [key for key in required if key not in rec]
    if mol is None or missing:
        raise RuntimeError(f"Invalid checkpoint {chk}; mol={mol is not None} missing={missing}")
    mo = np.asarray(rec["mo_coeff"])
    ncore = int(np.asarray(rec["ncore"]).ravel()[0])
    ncas = int(np.asarray(rec["ncas"]).ravel()[0])
    nelecas = tuple(int(x) for x in np.asarray(rec["nelecas"]).ravel())
    target_energy = float(np.asarray(rec["e_tot"]).ravel()[0])
    summary = json.loads(summary_path.read_text())
    vector = np.asarray(summary["field_vector_au"], dtype=float)

    driver = load_driver(Path(args.driver).resolve())
    hcore, energy_nuc, _ = driver.field_hamiltonian(mol, vector)
    mf = scf.RHF(mol)
    mf.max_memory = args.memory_mb
    mf.get_hcore = lambda *unused: hcore
    mf.energy_nuc = lambda *unused: energy_nuc
    mf.mo_coeff = mo
    mf.mo_occ = np.asarray(rec["mo_occ"])
    mf.converged = True

    mc = mcscf.CASCI(mf, ncas, nelecas, ncore=ncore)
    mc.max_memory = args.memory_mb
    mc.fcisolver.max_memory = args.fci_memory_mb
    mc.fcisolver.pspace_size = 1200
    mc.fcisolver.max_cycle = 400
    if hasattr(mc.fcisolver, "wfnsym"):
        mc.fcisolver.wfnsym = "A1"
    recovered_energy = float(mc.kernel(mo)[0])
    delta = recovered_energy - target_energy
    status = "PASS" if abs(delta) <= args.energy_tolerance else "FAIL"
    payload = {
        "status": status,
        "source_checkpoint": str(chk),
        "source_summary": str(summary_path),
        "field_vector_au": vector.tolist(),
        "ncore": ncore,
        "ncas": ncas,
        "nelecas": list(nelecas),
        "target_casscf_energy_hartree": target_energy,
        "recovered_casci_energy_hartree": recovered_energy,
        "energy_difference_hartree": delta,
        "energy_tolerance_hartree": args.energy_tolerance,
    }
    if status != "PASS":
        result_path.write_text(json.dumps(payload, indent=2) + "\n")
        raise RuntimeError(
            f"Fixed-orbital CASCI energy mismatch: {delta:.3e} Eh > {args.energy_tolerance:.3e}"
        )
    np.save(ci_path, np.asarray(mc.ci))
    np.save(mo_path, np.asarray(mc.mo_coeff))
    payload["ci_path"] = str(ci_path)
    payload["mo_coeff_path"] = str(mo_path)
    result_path.write_text(json.dumps(payload, indent=2) + "\n")
    print(
        f"RECOVERY_PASS E={recovered_energy:.15f} dE={delta:.3e} "
        f"ci_shape={np.asarray(mc.ci).shape}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
