#!/usr/bin/env python3
"""Collect and audit the ten-point OsO4 def2-TZVP quantum-geometry scan."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


POINTS = [0.650, 0.675, 0.700, 0.725, 0.750, 0.800, 0.850, 0.900, 0.950, 1.000]


def tag(x: float) -> str:
    return f"lambda_{x:.3f}".replace(".", "p")


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", required=True)
    args = p.parse_args()
    root = Path(args.root).resolve()
    rows, failures = [], []
    for lam in POINTS:
        path = root / tag(lam) / "qgeom.json"
        if not path.is_file():
            failures.append(f"lambda={lam:.3f}: missing {path}")
            continue
        data = json.loads(path.read_text())
        row = {
            "lambda": float(data["lambda"]),
            "field_au": float(data["field_au"]),
            "alpha_iso_au": float(data["alpha_iso_au"]),
            "many_electron_overlap_abs": float(data["many_electron_overlap_abs"]),
            "many_electron_fidelity": float(data["many_electron_fidelity"]),
            "g_ff_au": float(data["g_ff_au"]),
            "delta_geom_hartree": float(data["delta_geom_hartree"]),
            "closure_alpha_au": float(data["closure_alpha_au"]),
            "cross_core_determinant_abs": float(data["cross_core_determinant_abs"]),
            "effective_active_min_sv": float(data["effective_active_min_sv"]),
            "plus_recovery_energy_error_hartree": float(data["plus_recovery_energy_error_hartree"]),
            "minus_recovery_energy_error_hartree": float(data["minus_recovery_energy_error_hartree"]),
        }
        rows.append(row)
        closure = abs(row["closure_alpha_au"] - row["alpha_iso_au"])
        if data.get("status") != "PASS":
            failures.append(f"lambda={lam:.3f}: qgeom status is not PASS")
        if min(row["cross_core_determinant_abs"], row["effective_active_min_sv"]) < 0.99:
            failures.append(f"lambda={lam:.3f}: nonorthogonal-overlap continuity gate failed")
        if max(abs(row["plus_recovery_energy_error_hartree"]), abs(row["minus_recovery_energy_error_hartree"])) > 5.0e-9:
            failures.append(f"lambda={lam:.3f}: recovery energy gate failed")
        if closure > 1.0e-10:
            failures.append(f"lambda={lam:.3f}: factorization closure failed")

    rows.sort(key=lambda x: x["lambda"])
    csv_path = root / "OsO4_def2TZVP_qgeom_summary.csv"
    if rows:
        with csv_path.open("w", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    report = {
        "status": "PASS" if len(rows) == len(POINTS) and not failures else "FAIL",
        "expected_points": POINTS,
        "completed_points": [r["lambda"] for r in rows],
        "failures": failures,
        "summary_csv": str(csv_path),
        "minimum_alpha_grid_point": min(rows, key=lambda x: x["alpha_iso_au"])["lambda"] if rows else None,
        "minimum_alpha_grid_value_au": min((x["alpha_iso_au"] for x in rows), default=None),
    }
    audit_path = root / "OsO4_def2TZVP_qgeom_audit.json"
    audit_path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    print("\n lambda   alpha_iso       g_FF       Delta_geom/Eh      |overlap|")
    for row in rows:
        print(f" {row['lambda']:6.3f}  {row['alpha_iso_au']:10.5f}  {row['g_ff_au']:10.5f}  {row['delta_geom_hartree']:14.8f}  {row['many_electron_overlap_abs']:.10f}")
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
