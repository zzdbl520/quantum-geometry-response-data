#!/usr/bin/env bash
set -euo pipefail

BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PKG="$BASE/OsO4_def2TZVP_CI_recovery"
FFROOT="$BASE/OsO4_CAS24_def2TZVP_F1em3"
OUTROOT="$BASE/OsO4_CAS24_def2TZVP_CI_recovery"
DRIVER="$BASE/OsO4_def2TZVP_package/OsO4_CAS24fullvalence_finite_field_robust.py"
POINTS=(0.650 0.675 0.700 0.725 0.750 0.800 0.850 0.900 0.950 1.000)

mkdir -p "$OUTROOT"
for lam in "${POINTS[@]}"; do
  tag="lambda_${lam/./p}"
  ff="$FFROOT/$tag"
  out="$OUTROOT/$tag"
  mkdir -p "$out"
  echo "PAIR_START lambda=$lam"
  pids=()
  for sign in plus minus; do
    python -u "$PKG/recover_fixed_orbital_ci.py" \
      --checkpoint "$ff/$sign/casscf.chk" \
      --summary "$ff/$sign/summary.json" \
      --driver "$DRIVER" \
      --output-dir "$out/$sign" \
      > "$out/$sign.log" 2>&1 &
    pids+=("$!")
  done
  failed=0
  for pid in "${pids[@]}"; do
    if ! wait "$pid"; then failed=1; fi
  done
  if (( failed != 0 )); then
    echo "PAIR_FAILED lambda=$lam; inspect $out/plus.log and $out/minus.log" >&2
    exit 1
  fi
  tail -n 1 "$out/plus.log"
  tail -n 1 "$out/minus.log"
  python -u "$PKG/analyze_recovered_pair.py" \
    --plus-dir "$out/plus" \
    --minus-dir "$out/minus" \
    --plus-checkpoint "$ff/plus/casscf.chk" \
    --minus-checkpoint "$ff/minus/casscf.chk" \
    --polarizability-json "$ff/polarizability.json" \
    --output "$out/qgeom.json"
  echo "PAIR_DONE lambda=$lam"
done

python -u "$PKG/collect_full_scan.py" --root "$OUTROOT"
echo "FULL_SCAN_DONE $OUTROOT/OsO4_def2TZVP_qgeom_summary.csv"
