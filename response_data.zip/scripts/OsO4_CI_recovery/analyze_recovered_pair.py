#!/usr/bin/env python3
"""Compute the full nonorthogonal CAS overlap for a recovered +/-F pair."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from pyscf import fci
from pyscf.mcscf import chkfile as mc_chkfile


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--plus-dir", required=True)
    p.add_argument("--minus-dir", required=True)
    p.add_argument("--plus-checkpoint", required=True)
    p.add_argument("--minus-checkpoint", required=True)
    p.add_argument("--polarizability-json", required=True)
    p.add_argument("--output", required=True)
    args = p.parse_args()

    plus_dir, minus_dir = Path(args.plus_dir), Path(args.minus_dir)
    plus_rec = json.loads((plus_dir / "recovery.json").read_text())
    minus_rec = json.loads((minus_dir / "recovery.json").read_text())
    if plus_rec.get("status") != "PASS" or minus_rec.get("status") != "PASS":
        raise RuntimeError("Both fixed-orbital recoveries must PASS")
    ci_l = np.load(plus_dir / "ci.npy")
    ci_r = np.load(minus_dir / "ci.npy")
    mo_l = np.load(plus_dir / "mo_coeff.npy")
    mo_r = np.load(minus_dir / "mo_coeff.npy")
    mol_l, rec_l = mc_chkfile.load_mcscf(str(Path(args.plus_checkpoint).resolve()))
    mol_r, rec_r = mc_chkfile.load_mcscf(str(Path(args.minus_checkpoint).resolve()))
    ncore = int(np.asarray(rec_l["ncore"]).ravel()[0])
    ncas = int(np.asarray(rec_l["ncas"]).ravel()[0])
    nelecas = tuple(int(x) for x in np.asarray(rec_l["nelecas"]).ravel())
    if mol_l is None or mol_r is None:
        raise RuntimeError("Field checkpoints must contain mol")
    from pyscf import gto
    sao = gto.intor_cross("int1e_ovlp", mol_l, mol_r)
    cl, al = mo_l[:, :ncore], mo_l[:, ncore:ncore+ncas]
    cr, ar = mo_r[:, :ncore], mo_r[:, ncore:ncore+ncas]
    scc = cl.conj().T @ sao @ cr
    sca = cl.conj().T @ sao @ ar
    sac = al.conj().T @ sao @ cr
    saa = al.conj().T @ sao @ ar
    sign, logdet = np.linalg.slogdet(scc)
    if sign == 0:
        raise RuntimeError("Singular cross-core overlap")
    seff = saa - sac @ np.linalg.solve(scc, sca)
    ov_active = fci.addons.overlap(ci_l, ci_r, ncas, nelecas, s=seff)
    overlap = (sign * np.exp(logdet))**2 * ov_active
    polar = json.loads(Path(args.polarizability_json).read_text())
    field = float(polar["field_magnitude_au"])
    fidelity = min(1.0, max(np.finfo(float).tiny, abs(overlap)**2))
    gff = -np.log(fidelity) / (2.0*field)**2
    alpha = float(polar["alpha_iso_au"])
    sv = np.linalg.svd(seff, compute_uv=False)
    result = {
        "status": "PASS",
        "lambda": float(polar["lambda"]),
        "field_au": field,
        "alpha_iso_au": alpha,
        "many_electron_overlap_abs": float(abs(overlap)),
        "many_electron_fidelity": float(fidelity),
        "g_ff_au": float(gff),
        "delta_geom_hartree": float(alpha/(2.0*gff)),
        "closure_alpha_au": float(2.0*gff*(alpha/(2.0*gff))),
        "cross_core_determinant_abs": float(np.exp(logdet)),
        "effective_active_min_sv": float(sv.min()),
        "effective_active_max_sv": float(sv.max()),
        "plus_recovery_energy_error_hartree": plus_rec["energy_difference_hartree"],
        "minus_recovery_energy_error_hartree": minus_rec["energy_difference_hartree"],
    }
    Path(args.output).write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
