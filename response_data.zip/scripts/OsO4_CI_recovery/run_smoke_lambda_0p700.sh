#!/usr/bin/env bash
set -euo pipefail

BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PKG="$BASE/OsO4_def2TZVP_CI_recovery"
FF="$BASE/OsO4_CAS24_def2TZVP_F1em3/lambda_0p700"
OUT="$BASE/OsO4_CAS24_def2TZVP_CI_recovery/lambda_0p700"
DRIVER="$BASE/OsO4_def2TZVP_package/OsO4_CAS24fullvalence_finite_field_robust.py"
mkdir -p "$OUT"

for sign in plus minus; do
  python -u "$PKG/recover_fixed_orbital_ci.py" \
    --checkpoint "$FF/$sign/casscf.chk" \
    --summary "$FF/$sign/summary.json" \
    --driver "$DRIVER" \
    --output-dir "$OUT/$sign" \
    > "$OUT/$sign.log" 2>&1
  tail -n 2 "$OUT/$sign.log"
done

python -u "$PKG/analyze_recovered_pair.py" \
  --plus-dir "$OUT/plus" \
  --minus-dir "$OUT/minus" \
  --plus-checkpoint "$FF/plus/casscf.chk" \
  --minus-checkpoint "$FF/minus/casscf.chk" \
  --polarizability-json "$FF/polarizability.json" \
  --output "$OUT/qgeom.json"

echo "SMOKE_DONE $OUT/qgeom.json"
