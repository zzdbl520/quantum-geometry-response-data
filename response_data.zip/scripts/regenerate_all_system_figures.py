#!/usr/bin/env python3
"""Regenerate standardized archive figures from the final derived tables."""

from __future__ import annotations

import csv
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = ROOT / "generated"
OUT.mkdir(exist_ok=True)

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 8.4,
    "axes.linewidth": 0.85,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.hashsalt": "qgeom-si",
})


def rows(path):
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle))


def values(table, key):
    return np.asarray([float(row[key]) for row in table])


def style(ax):
    ax.minorticks_off()
    ax.tick_params(which="major", direction="in", top=True, right=True, length=4.0, width=0.8)


def save(fig, stem):
    for extension in ("pdf", "png"):
        kwargs = {"dpi": 400} if extension == "png" else {"metadata": {"CreationDate": None, "ModDate": None}}
        fig.savefig(OUT / f"{stem}.{extension}", bbox_inches="tight", pad_inches=0.04, **kwargs)
    plt.close(fig)


def diatomic_figure(label, filename, coordinate, keys):
    table = rows(DATA / filename)
    x = values(table, coordinate)
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 5.0), gridspec_kw={"hspace": 0.32, "wspace": 0.28})
    panels = (
        (keys["alpha"], r"Polarizability, $\alpha$ (a.u.)"),
        (keys["g"], r"Field metric, $g_{FF}$ (a.u.)"),
        (keys["delta"], r"Effective scale, $\Delta_{\rm geom}$ ($E_h$)"),
    )
    colors = ("#276FBF", "#C23B3B", "#202020")
    names = (r"$\perp$", r"$\parallel$", r"iso")
    for ax, (component_keys, ylabel) in zip(axes.flat[:3], panels):
        style(ax)
        for key, color, name in zip(component_keys, colors, names):
            ax.plot(x, values(table, key), color=color, lw=1.35, marker="o", ms=2.7,
                    mfc="white", mec=color, label=name)
        ax.set_xlabel(r"Bond length, $R$ ($\AA$)")
        ax.set_ylabel(ylabel)
    axes[0, 0].legend(frameon=False, ncol=3, loc="best")
    ax = axes[1, 1]
    style(ax)
    giso = values(table, keys["g"][2])
    diso = values(table, keys["delta"][2])
    midpoint = 0.5 * (x[:-1] + x[1:])
    dlogg = np.diff(np.log(giso)) / np.diff(x)
    dlogd = np.diff(np.log(diso)) / np.diff(x)
    ax.axhline(0.0, color="0.6", lw=0.8, ls="--")
    ax.plot(midpoint, dlogg, color=colors[0], lw=1.4, label=r"$d\ln g/dR$")
    ax.plot(midpoint, dlogd, color=colors[1], lw=1.4, label=r"$d\ln\Delta/dR$")
    ax.plot(midpoint, dlogg + dlogd, color=colors[2], lw=1.5, label=r"$d\ln\alpha/dR$")
    ax.set_xlabel(r"Bond length, $R$ ($\AA$)")
    ax.set_ylabel(r"Logarithmic slope ($\AA^{-1}$)")
    ax.legend(frameon=False, fontsize=7.5)
    for panel, ax in zip("abcd", axes.flat):
        ax.text(-0.14, 1.04, f"({panel})", transform=ax.transAxes, ha="left", va="bottom")
    fig.suptitle(f"{label}: archived quantum-geometric response", y=0.995, fontsize=10)
    save(fig, f"{label}_archive_reproduction")


def main():
    common = {
        "alpha": ("alpha_perp_au", "alpha_parallel_au", "alpha_iso_au"),
        "g": ("g_perp_au", "g_parallel_au", "g_iso_au"),
        "delta": ("Delta_perp_Eh", "Delta_parallel_Eh", "Delta_iso_Eh"),
    }
    diatomic_figure("H2", "H2_qgeom_derived.csv", "R_Angstrom", common)
    diatomic_figure("N2", "N2_qgeom_derived.csv", "R_Angstrom", common)
    cr2 = {
        "alpha": common["alpha"],
        "g": common["g"],
        "delta": ("Delta_geom_perp_Eh", "Delta_geom_parallel_Eh", "Delta_geom_iso_Eh"),
    }
    diatomic_figure("Cr2", "Cr2_aug_global40_derived.csv", "R_Angstrom", cr2)
    f2 = {
        "alpha": ("alpha_perp_au", "alpha_parallel_au", "alpha_iso_au"),
        "g": ("gff_perp_au", "gff_parallel_au", "gff_iso_au"),
        "delta": ("delta_eff_perp_hartree", "delta_eff_parallel_hartree", "delta_eff_iso_hartree"),
    }
    diatomic_figure("F2", "F2_stage2f_publication_data.csv", "r_angstrom", f2)
    print(f"WROTE standardized H2/N2/Cr2/F2 figures to {OUT}")


if __name__ == "__main__":
    main()
