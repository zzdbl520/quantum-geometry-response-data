#!/usr/bin/env python3
"""Cross-check the published Cu2O2 response tables and both local fits."""

import csv
import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1] / "data"
TZ = ROOT / "Cu2O2_def2TZVP"
SV = ROOT / "Cu2O2_def2SVP_parent"


def records(path):
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def vertex(rows, xkey, ykey, mode):
    values = np.array([float(row[ykey]) for row in rows])
    index = int(np.argmin(values) if mode == "min" else np.argmax(values))
    if not 0 < index < len(rows) - 1:
        raise AssertionError("Stationary point is not bracketed by computed data")
    local = rows[index - 1 : index + 2]
    x = [float(row[xkey]) for row in local]
    y = [float(row[ykey]) for row in local]
    a, b, _ = np.polyfit(x, y, 2)
    if (a > 0) != (mode == "min"):
        raise AssertionError("Local fit has the wrong curvature")
    return -b / (2 * a)


points = records(TZ / "DEF2TZVP_25POINT_RESPONSE_POINTS.csv")
metric = records(TZ / "DEF2TZVP_FIELD_QMETRIC.csv")
assert len(points) == len(metric) == 25
assert [p["point"] for p in points] == [m["point"] for m in metric]

for m in metric:
    alpha = float(m["alpha_xx_energy_au"])
    g = float(m["g_FxFx_FS_au"])
    scale = float(m["Delta_geom_x_Eh"])
    assert abs(alpha / (2 * g) - scale) < 1e-10

e_min = vertex(points, "O_O_A", "zero_energy_Eh", "min")
a_min = vertex(metric, "O_O_A", "alpha_xx_energy_au", "min")
assert abs(e_min - 1.6238986411788814) < 1e-5
assert abs(a_min - 1.7490527364361133) < 1e-5

parent = records(SV / "PARENT_CASCI2816_LOCAL_RESPONSE.csv")
audit = json.loads((SV / "PARENT_CASCI2816_LOCAL_SUMMARY.json").read_text())
assert len(parent) == 3 and audit["decision"] == "PARENT_CASCI2816_LOCAL_MINIMUM_VALIDATED"
source_min = vertex(parent, "R_OO_A", "source_CAS86_alpha_energy_five_au", "min")
parent_min = vertex(parent, "R_OO_A", "parent_CASCI2816_alpha_energy_five_au", "min")
assert abs(source_min - 1.7569975202031702) < 1e-6
assert abs(parent_min - 1.7541949558955614) < 1e-6
assert abs(parent_min - source_min) < 0.003
assert all(
    0 < float(p["parent_minus_source_alpha_energy_five_au"])
    / float(p["source_CAS86_alpha_energy_five_au"]) < 0.002
    for p in parent
)
print("Cu2O2 PASS: 25-point def2-TZVP factorization and independent local def2-SVP parent-CI minimum")
