#!/usr/bin/env python3
from pathlib import Path
import csv
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import FormatStrFormatter

HERE = Path(__file__).resolve().parent
CSV = (HERE.parent / "data" / "OsO4_def2TZVP" /
       "OsO4_CAS24_def2TZVP_CI_recovery" /
       "OsO4_def2TZVP_qgeom_summary.csv")
rows = list(csv.DictReader(CSV.open()))
x = np.array([float(r["lambda"]) for r in rows])
g = np.array([float(r["g_ff_au"]) for r in rows])
d = np.array([float(r["delta_geom_hartree"]) for r in rows])

def vertex(y, ids):
    c = np.polyfit(x[ids], y[ids], 2)
    xv = -c[1] / (2*c[0])
    return xv, np.polyval(c, xv), c

gx, gy, gc = vertex(g, [2,3,4])
dx, dy, dc = vertex(d, [3,4,5])

plt.rcParams.update({"font.family":"DejaVu Sans", "font.size":9.2,
                     "axes.linewidth":0.9, "pdf.fonttype":42, "ps.fonttype":42,
                     "svg.hashsalt":"qgeom-si"})
blue, red = "#276FBF", "#C23B3B"
fig, ax = plt.subplots(figsize=(3.75, 2.90))
ax.minorticks_off()
ax.tick_params(which="major", direction="in", length=4.2, width=0.85,
               top=True, right=True, colors="black")
for s in ax.spines.values():
    s.set_visible(True); s.set_color("black"); s.set_linewidth(0.9)
ax.xaxis.set_major_formatter(FormatStrFormatter("%.2f"))

lg, = ax.plot(x, g, color=blue, lw=1.7, marker="o", ms=4,
              mfc="white", mec=blue, mew=1.0, label=r"$\bar g_{FF}$")
xx = np.linspace(0.700,0.750,120)
ax.plot(xx, np.polyval(gc,xx), color=blue, lw=0.9, alpha=0.55)
ax.scatter([gx],[gy], marker="v", s=43, color=blue, zorder=5)
ax.set_xlim(0.635,1.015); ax.set_ylim(15,54)
ax.set_xticks([0.65,0.70,0.75,0.80,0.85,0.90,0.95,1.00])
ax.set_yticks([20,30,40,50])
ax.set_xlabel(r"Compression coordinate, $\lambda$")
ax.set_ylabel(r"Field metric, $\bar g_{FF}$ (a.u.)")

ad = ax.twinx(); ad.minorticks_off()
ad.tick_params(which="major", direction="in", length=4.2, width=0.85,
               right=True, left=False, colors="black")
ld, = ad.plot(x,d,color=red,lw=1.7,marker="s",ms=3.8,
              mfc="white",mec=red,mew=1.0,label=r"$\bar\Delta_{\rm geom}$")
xx=np.linspace(0.725,0.800,120)
ad.plot(xx,np.polyval(dc,xx),color=red,lw=0.9,alpha=0.55)
ad.scatter([dx],[dy],marker="v",s=43,color=red,zorder=5)
ad.set_ylim(0.42,0.79); ad.set_yticks([0.45,0.55,0.65,0.75])
ad.set_ylabel(r"$\bar\Delta_{\rm geom}$ ($E_{\rm h}$)")
ad.spines["right"].set_color("black"); ad.spines["right"].set_linewidth(0.9)
ax.legend([lg,ld],[lg.get_label(),ld.get_label()],frameon=False,
          loc="lower center",bbox_to_anchor=(0.53,1.02),ncol=2,
          handlelength=1.6,columnspacing=1.1,borderaxespad=0)
ax.annotate(r"$\lambda_{\min}^{\bar g}=0.727$",(gx,gy),xytext=(-5,18),
            textcoords="offset points",ha="center",va="bottom",color=blue,
            arrowprops=dict(arrowstyle="-",lw=0.7,color=blue))
ad.annotate(r"$\lambda_{\max}^{\bar\Delta}=0.744$",(dx,dy),xytext=(32,-22),
            textcoords="offset points",ha="left",va="top",color=red,
            arrowprops=dict(arrowstyle="-",lw=0.7,color=red))
fig.subplots_adjust(left=0.16,right=0.84,bottom=0.20,top=0.86)
outdir = HERE.parent / "generated"
outdir.mkdir(exist_ok=True)
for ext in ("pdf","svg","png"):
    kw={"dpi":600} if ext=="png" else ({"metadata":{"CreationDate":None,"ModDate":None}} if ext=="pdf" else {})
    fig.savefig(outdir/f"OsO4_def2TZVP_SI_factor_competition.{ext}",
                bbox_inches="tight",pad_inches=0.03,**kw)
