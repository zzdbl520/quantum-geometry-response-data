#!/usr/bin/env python3
"""Independent numerical audit for the SI archive.

The script uses only the archived, machine-readable final tables.  It checks
row counts, alpha = 2 g Delta closure, characteristic geometries, selected
quality gates, and the OsO4 logarithmic-slope cancellation.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = ROOT / "generated"
OUT.mkdir(exist_ok=True)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle))


def vector(rows: list[dict[str, str]], key: str) -> np.ndarray:
    return np.asarray([float(row[key]) for row in rows], dtype=float)


def local_vertex(x: np.ndarray, y: np.ndarray, kind: str, points: int) -> tuple[float, float]:
    center = int(np.argmax(y) if kind == "maximum" else np.argmin(y))
    start = max(0, min(len(x) - points, center - points // 2))
    stop = start + points
    coef = np.polyfit(x[start:stop], y[start:stop], 2)
    xv = -coef[1] / (2.0 * coef[0])
    return float(xv), float(np.polyval(coef, xv))


def record_check(checks: list[dict], name: str, value, expected, tolerance=0.0) -> None:
    if isinstance(value, (int, float)) and isinstance(expected, (int, float)):
        passed = abs(float(value) - float(expected)) <= tolerance
    else:
        passed = value == expected
    checks.append({
        "name": name,
        "value": value,
        "expected": expected,
        "tolerance": tolerance,
        "pass": bool(passed),
    })


def factorization_error(rows, alpha_key, g_key, delta_key) -> float:
    alpha = vector(rows, alpha_key)
    g = vector(rows, g_key)
    delta = vector(rows, delta_key)
    return float(np.max(np.abs(alpha - 2.0 * g * delta)))


def audit_h2_n2(label: str, filename: str, expected_rows: int, targets: tuple[float, float, float]):
    rows = read_csv(DATA / filename)
    checks: list[dict] = []
    record_check(checks, "row_count", len(rows), expected_rows)
    for component in ("perp", "parallel", "iso"):
        error = factorization_error(
            rows, f"alpha_{component}_au", f"g_{component}_au", f"Delta_{component}_Eh"
        )
        record_check(checks, f"factorization_{component}_max_abs_error", error, 0.0, 1.0e-11)
    x = vector(rows, "R_Angstrom")
    alpha_x, alpha_y = local_vertex(x, vector(rows, "alpha_iso_au"), "maximum", 5)
    g_x, g_y = local_vertex(x, vector(rows, "g_iso_au"), "maximum", 5)
    delta_x, delta_y = local_vertex(x, vector(rows, "Delta_iso_Eh"), "minimum", 5)
    for name, value, target in zip(
        ("R_alpha_max_A", "R_g_max_A", "R_Delta_min_A"),
        (alpha_x, g_x, delta_x), targets,
    ):
        record_check(checks, name, value, target, 7.0e-7)
    record_check(checks, "ordered_characteristic_geometries", alpha_x < g_x < delta_x, True)
    return {
        "status": "PASS" if all(item["pass"] for item in checks) else "FAIL",
        "checks": checks,
        "fitted_values": {
            "alpha_max_au": alpha_y,
            "g_max_au": g_y,
            "Delta_min_Eh": delta_y,
        },
    }


def audit_cr2():
    rows = read_csv(DATA / "Cr2_aug_global40_derived.csv")
    extrema = read_csv(DATA / "Cr2_aug_global40_extrema.csv")
    balance = read_csv(DATA / "Cr2_aug_global40_stationary_balance.csv")
    checks: list[dict] = []
    record_check(checks, "row_count", len(rows), 40)
    for component, delta_key in (
        ("perp", "Delta_geom_perp_Eh"),
        ("parallel", "Delta_geom_parallel_Eh"),
        ("iso", "Delta_geom_iso_Eh"),
    ):
        error = factorization_error(rows, f"alpha_{component}_au", f"g_{component}_au", delta_key)
        record_check(checks, f"factorization_{component}_max_abs_error", error, 0.0, 3.0e-12)
    record_check(checks, "stationary_point_count", len(extrema), 6)
    target_positions = [1.769322623, 1.798385717, 1.819607024, 3.675031010, 3.813159727, 4.013855375]
    for row, target in zip(extrema, target_positions):
        record_check(
            checks,
            f"{row['region']}_{row['quantity']}_{row['extremum']}_A",
            float(row["R_fit_Angstrom"]),
            target,
            6.0e-10,
        )
    max_balance = max(abs(float(row["slope_sum_Angstrom-1"])) for row in balance)
    record_check(checks, "stationary_slope_closure", max_balance, 0.0, 1.0e-12)
    return {"status": "PASS" if all(item["pass"] for item in checks) else "FAIL", "checks": checks}


def audit_f2():
    rows = read_csv(DATA / "F2_stage2f_publication_data.csv")
    physical = json.loads((DATA / "F2_stage2f_physical_audit.json").read_text())
    checks: list[dict] = []
    record_check(checks, "row_count", len(rows), 22)
    for component in ("perp", "parallel", "iso"):
        error = factorization_error(
            rows,
            f"alpha_{component}_au",
            f"gff_{component}_au",
            f"delta_eff_{component}_hartree",
        )
        record_check(checks, f"factorization_{component}_max_abs_error", error, 0.0, 1.0e-12)
    x = vector(rows, "r_angstrom")
    alpha_x, alpha_y = local_vertex(x, vector(rows, "alpha_iso_au"), "maximum", 3)
    record_check(checks, "primary_R_alpha_max_A", alpha_x, 1.5769935893, 2.0e-9)
    summary = physical["stage2f_summary"]
    record_check(checks, "all_quality_pass", summary["all_quality_pass"], True)
    record_check(checks, "expected_field_states", summary["expected_field_states"], 264)
    record_check(checks, "certified_field_states", summary["certified_field_states"], 264)
    record_check(checks, "all_field_limit_fits_pass", summary["all_field_limit_fits_pass"], True)
    return {
        "status": "PASS" if all(item["pass"] for item in checks) else "FAIL",
        "checks": checks,
        "fitted_values": {"primary_alpha_max_au": alpha_y},
    }


def audit_oso4():
    base = DATA / "OsO4_def2TZVP" / "OsO4_CAS24_def2TZVP_CI_recovery"
    rows = read_csv(base / "OsO4_def2TZVP_qgeom_summary.csv")
    archived_audit = json.loads((base / "OsO4_def2TZVP_qgeom_audit.json").read_text())
    checks: list[dict] = []
    record_check(checks, "row_count", len(rows), 10)
    error = factorization_error(rows, "alpha_iso_au", "g_ff_au", "delta_geom_hartree")
    record_check(checks, "factorization_max_abs_error", error, 0.0, 1.0e-12)
    fidelity_error = float(np.max(np.abs(
        vector(rows, "many_electron_fidelity") - vector(rows, "many_electron_overlap_abs") ** 2
    )))
    record_check(checks, "fidelity_overlap_square_closure", fidelity_error, 0.0, 1.0e-14)
    x = vector(rows, "lambda")
    alpha_x, alpha_y = local_vertex(x, vector(rows, "alpha_iso_au"), "minimum", 3)
    g_x, g_y = local_vertex(x, vector(rows, "g_ff_au"), "minimum", 3)
    delta_x, delta_y = local_vertex(x, vector(rows, "delta_geom_hartree"), "maximum", 3)
    for name, value, target in (
        ("lambda_alpha_min", alpha_x, 0.70474703368),
        ("lambda_g_min", g_x, 0.72677438350),
        ("lambda_Delta_max", delta_x, 0.74355067560),
    ):
        record_check(checks, name, value, target, 2.0e-10)
    record_check(checks, "ordered_characteristic_coordinates", alpha_x < g_x < delta_x, True)
    midpoint = 0.5 * (x[:-1] + x[1:])
    dlogg = np.diff(np.log(vector(rows, "g_ff_au"))) / np.diff(x)
    dlogd = np.diff(np.log(vector(rows, "delta_geom_hartree"))) / np.diff(x)
    dloga = dlogg + dlogd
    crossing = np.where(dloga[:-1] * dloga[1:] <= 0.0)[0]
    i = int(crossing[0])
    xzero = midpoint[i] - dloga[i] * (midpoint[i + 1] - midpoint[i]) / (dloga[i + 1] - dloga[i])
    t = (xzero - midpoint[i]) / (midpoint[i + 1] - midpoint[i])
    gzero = dlogg[i] + t * (dlogg[i + 1] - dlogg[i])
    dzero = dlogd[i] + t * (dlogd[i + 1] - dlogd[i])
    record_check(checks, "lambda_slope_cancellation", float(xzero), 0.70471571904, 2.0e-10)
    record_check(checks, "slope_cancellation_closure", float(gzero + dzero), 0.0, 1.0e-12)
    record_check(checks, "archived_audit_status", archived_audit["status"], "PASS")
    max_recovery_error = max(
        np.max(np.abs(vector(rows, "plus_recovery_energy_error_hartree"))),
        np.max(np.abs(vector(rows, "minus_recovery_energy_error_hartree"))),
    )
    record_check(checks, "maximum_CI_recovery_energy_error_Eh", float(max_recovery_error), 0.0, 2.3e-9)
    return {
        "status": "PASS" if all(item["pass"] for item in checks) else "FAIL",
        "checks": checks,
        "fitted_values": {
            "alpha_min_au": alpha_y,
            "g_min_au": g_y,
            "Delta_max_Eh": delta_y,
            "dln_g_at_cancellation": float(gzero),
            "dln_Delta_at_cancellation": float(dzero),
        },
    }


def main() -> int:
    systems = {
        "H2": audit_h2_n2("H2", "H2_qgeom_derived.csv", 29, (1.8075472192, 1.8445350893, 1.9092877559)),
        "N2": audit_h2_n2("N2", "N2_qgeom_derived.csv", 38, (1.8693217228, 1.9984086819, 2.1466819072)),
        "Cr2": audit_cr2(),
        "F2": audit_f2(),
        "OsO4": audit_oso4(),
    }
    status = "PASS" if all(item["status"] == "PASS" for item in systems.values()) else "FAIL"
    report = {
        "title": "Quantum Geometry Governs Molecular Polarizability Extrema",
        "scope": ["H2", "N2", "Cr2", "F2", "OsO4"],
        "status": status,
        "systems": systems,
    }
    destination = OUT / "reproduction_summary.json"
    destination.write_text(json.dumps(report, indent=2) + "\n")
    for label, item in systems.items():
        print(f"{label:5s} {item['status']}")
    print(f"OVERALL {status}")
    print(destination)
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
