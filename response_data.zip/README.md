# Chemical Science: response data and numerical audit

This archive accompanies **Quantum Geometry Governs Molecular Response Reversals**.
The article and current Supporting Information PDF are the authoritative narrative.

Run `bash run_reproduction.sh` for the existing H2, N2, Cr2, F2, and OsO4
derived-data audit, figure regeneration, and the separate Cu2O2 consistency
check. Run `bash verify_manifest.sh` for a SHA-256 integrity check of the
distributed inputs. The analysis scripts use Python 3, NumPy, and Matplotlib.

The `data/Cu2O2_def2TZVP/` folder contains the 25-geometry energy,
polarizability, field metric, geometric energy scale, and fit values used in
the main Cu2O2 response figure. Its field metric uses the squared
Fubini--Study angle at h = 0.00025 a.u. The
`data/Cu2O2_def2SVP_parent/` folder contains a distinct three-geometry,
five-field CASSCF(8e,6o) source / fixed-orbital CASCI(28e,16o) parent test,
its protocol and audit. These **def2-SVP** results do not represent a
def2-TZVP parent-space or dynamic-correlation calculation.

The two Cu2O2 analytical figures can be rebuilt from their archived sources:

```bash
cd scripts/Cu2O2_two_panel_source && python make_two_panel_figure.py
cd ../..
python scripts/Cu2O2_validation_source/make_cu2o2_casci_publication_assets.py \
  --input scripts/Cu2O2_validation_source/source_data \
  --output generated/Cu2O2_validation
```

The H2, N2, Cr2, F2, and OsO4 data, analysis and plotting scripts are
preserved from the verified numerical package. The original wavefunction
checkpoints, AO integrals and scratch files are not included, so reproducing
the quantum chemistry from first principles requires those original inputs.
